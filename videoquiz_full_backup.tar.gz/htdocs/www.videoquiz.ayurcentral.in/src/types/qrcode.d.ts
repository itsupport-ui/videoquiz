declare module "qrcode";

