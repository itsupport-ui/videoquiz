declare module 'pdfkit';

