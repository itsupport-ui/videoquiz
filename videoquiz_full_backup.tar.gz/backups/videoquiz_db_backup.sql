--
-- PostgreSQL database dump
--

\restrict UWJdsNTpGSzgPMQTFC4NJfKhKp7CGq0aiLQh69X7oftRqH2aDpbBjAivMKfsRAL

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: itsupport
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'EMPLOYEE'
);


ALTER TYPE public."Role" OWNER TO itsupport;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Attempt; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."Attempt" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "quizId" text NOT NULL,
    "attemptNo" integer NOT NULL,
    score integer NOT NULL,
    passed boolean NOT NULL,
    "answersJson" jsonb NOT NULL,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Attempt" OWNER TO itsupport;

--
-- Name: Certificate; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."Certificate" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "totalScore" integer NOT NULL,
    "filePath" text NOT NULL,
    "mainModuleId" integer
);


ALTER TABLE public."Certificate" OWNER TO itsupport;

--
-- Name: EmployeeMainModuleProgress; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."EmployeeMainModuleProgress" (
    id integer NOT NULL,
    "employeeId" text NOT NULL,
    "mainModuleId" integer NOT NULL,
    "currentSubmoduleIndex" integer DEFAULT 0 NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "completionDate" timestamp(3) without time zone
);


ALTER TABLE public."EmployeeMainModuleProgress" OWNER TO itsupport;

--
-- Name: EmployeeMainModuleProgress_id_seq; Type: SEQUENCE; Schema: public; Owner: itsupport
--

CREATE SEQUENCE public."EmployeeMainModuleProgress_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EmployeeMainModuleProgress_id_seq" OWNER TO itsupport;

--
-- Name: EmployeeMainModuleProgress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: itsupport
--

ALTER SEQUENCE public."EmployeeMainModuleProgress_id_seq" OWNED BY public."EmployeeMainModuleProgress".id;


--
-- Name: MainModule; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."MainModule" (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    "youtubeId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "certificateTemplate" text,
    "orderIndex" integer NOT NULL
);


ALTER TABLE public."MainModule" OWNER TO itsupport;

--
-- Name: MainModule_id_seq; Type: SEQUENCE; Schema: public; Owner: itsupport
--

CREATE SEQUENCE public."MainModule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MainModule_id_seq" OWNER TO itsupport;

--
-- Name: MainModule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: itsupport
--

ALTER SEQUENCE public."MainModule_id_seq" OWNED BY public."MainModule".id;


--
-- Name: Module; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."Module" (
    id text NOT NULL,
    "order" integer NOT NULL,
    title text NOT NULL,
    description text,
    "youtubeId" text NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "mainModuleId" integer,
    "orderWithinMain" integer
);


ALTER TABLE public."Module" OWNER TO itsupport;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."Question" (
    id text NOT NULL,
    "quizId" text NOT NULL,
    text text NOT NULL,
    options text[],
    "correctIndex" integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "correctAnswer" text,
    "optionA" text,
    "optionB" text,
    "optionC" text,
    "optionD" text,
    "orderIndex" integer,
    "questionType" text
);


ALTER TABLE public."Question" OWNER TO itsupport;

--
-- Name: QuestionImport; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."QuestionImport" (
    id integer NOT NULL,
    "uploadedById" text NOT NULL,
    "fileName" text NOT NULL,
    "uploadDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "totalQuestions" integer NOT NULL,
    "successfulImports" integer NOT NULL,
    "failedImports" integer NOT NULL,
    "errorLog" text
);


ALTER TABLE public."QuestionImport" OWNER TO itsupport;

--
-- Name: QuestionImport_id_seq; Type: SEQUENCE; Schema: public; Owner: itsupport
--

CREATE SEQUENCE public."QuestionImport_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."QuestionImport_id_seq" OWNER TO itsupport;

--
-- Name: QuestionImport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: itsupport
--

ALTER SEQUENCE public."QuestionImport_id_seq" OWNED BY public."QuestionImport".id;


--
-- Name: Quiz; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."Quiz" (
    id text NOT NULL,
    "moduleId" text NOT NULL,
    "passScore" integer NOT NULL,
    "timeLimitSeconds" integer DEFAULT 300 NOT NULL
);


ALTER TABLE public."Quiz" OWNER TO itsupport;

--
-- Name: User; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role public."Role" DEFAULT 'EMPLOYEE'::public."Role" NOT NULL,
    "passwordHash" text NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "mfaSecret" text,
    "disabledAt" timestamp(3) without time zone,
    "lockedUntil" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO itsupport;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: itsupport
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO itsupport;

--
-- Name: EmployeeMainModuleProgress id; Type: DEFAULT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."EmployeeMainModuleProgress" ALTER COLUMN id SET DEFAULT nextval('public."EmployeeMainModuleProgress_id_seq"'::regclass);


--
-- Name: MainModule id; Type: DEFAULT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."MainModule" ALTER COLUMN id SET DEFAULT nextval('public."MainModule_id_seq"'::regclass);


--
-- Name: QuestionImport id; Type: DEFAULT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."QuestionImport" ALTER COLUMN id SET DEFAULT nextval('public."QuestionImport_id_seq"'::regclass);


--
-- Data for Name: Attempt; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."Attempt" (id, "userId", "quizId", "attemptNo", score, passed, "answersJson", "submittedAt") FROM stdin;
cmhj38ezv00bujus4grl31u6v	cmhj2sveo00bsjus4zm3lbtm5	cmhbvwu7p002qjus4wd964v8j	1	60	f	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 2, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 1, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-03 11:59:58.699
cmhj3ah2600bwjus4t1ou6j6m	cmhj2sveo00bsjus4zm3lbtm5	cmhbvwu7p002qjus4wd964v8j	2	100	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 1, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-03 12:01:34.686
cmhk3zaoy00bzjus4xht24eaz	cmhj2sveo00bsjus4zm3lbtm5	cmhbuisyj001ejus4c4v4urph	1	100	t	[{"optionKey": 1, "questionId": "cmheqnszk006ijus469wgybvy"}, {"optionKey": 0, "questionId": "cmheqo5ix006kjus4jmh0gw31"}, {"optionKey": 1, "questionId": "cmheqp7u9006mjus40g6mz99z"}, {"optionKey": 0, "questionId": "cmheqqfzq006qjus42x4ajotl"}, {"optionKey": 0, "questionId": "cmheqsb1v006sjus4if69qpxu"}]	2025-11-04 05:08:39.009
cmhk583g70001jusuy2yl47eq	cmhj2sveo00bsjus4zm3lbtm5	cmhbuvg3g001wjus4d8oed9ls	1	100	t	[{"optionKey": 3, "questionId": "cmhhqpd9c00aqjus4dher86bu"}, {"optionKey": 0, "questionId": "cmhhqr36900asjus4he7no7df"}, {"optionKey": 0, "questionId": "cmhhqx9be00aujus46fupain3"}, {"optionKey": 0, "questionId": "cmhhqyz6500awjus4dopt6fwr"}, {"optionKey": 0, "questionId": "cmhhr0b8b00ayjus44lzexg7b"}]	2025-11-04 05:43:29.142
cmhk7unvi0001juhz00rf7d6z	cmhj3gkgo00bxjus4teiqpmwk	cmhbvwu7p002qjus4wd964v8j	1	80	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 1, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 2, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-04 06:57:01.277
cmhk80x6q0003juhzzdf8ldge	cmhj3gkgo00bxjus4teiqpmwk	cmhbuisyj001ejus4c4v4urph	1	80	t	[{"optionKey": 1, "questionId": "cmheqnszk006ijus469wgybvy"}, {"optionKey": 0, "questionId": "cmheqo5ix006kjus4jmh0gw31"}, {"optionKey": 1, "questionId": "cmheqp7u9006mjus40g6mz99z"}, {"optionKey": 1, "questionId": "cmheqqfzq006qjus42x4ajotl"}, {"optionKey": 0, "questionId": "cmheqsb1v006sjus4if69qpxu"}]	2025-11-04 07:01:53.283
cmhk836600005juhzp18iq4ak	cmhj3gkgo00bxjus4teiqpmwk	cmhbuvg3g001wjus4d8oed9ls	1	100	t	[{"optionKey": 3, "questionId": "cmhhqpd9c00aqjus4dher86bu"}, {"optionKey": 0, "questionId": "cmhhqr36900asjus4he7no7df"}, {"optionKey": 0, "questionId": "cmhhqx9be00aujus46fupain3"}, {"optionKey": 0, "questionId": "cmhhqyz6500awjus4dopt6fwr"}, {"optionKey": 0, "questionId": "cmhhr0b8b00ayjus44lzexg7b"}]	2025-11-04 07:03:38.233
cmhk8uj6x000hjuhzba2i5kr0	cmhj3gkgo00bxjus4teiqpmwk	cmhht5ev300bejus4kgumi0vi	1	100	t	[{"optionKey": 1, "questionId": "cmhk8kflj0007juhz95mgm348"}, {"optionKey": 2, "questionId": "cmhk8m8z40009juhzw3pvakif"}, {"optionKey": 2, "questionId": "cmhk8q21l000bjuhzb6fctr0m"}, {"optionKey": 0, "questionId": "cmhk8qjka000djuhzs5rdzxpm"}, {"optionKey": 1, "questionId": "cmhk8r838000fjuhzq0tk2nw8"}]	2025-11-04 07:24:54.825
cmhk8y5xr000jjuhzx4s4xjzr	cmhj3gkgo00bxjus4teiqpmwk	cmh98n3xn000bjus4t2641bic	1	60	f	[{"optionKey": 1, "questionId": "cmheihsja002sjus45xvghic0"}, {"optionKey": 0, "questionId": "cmheiikjw002ujus46z8mhycv"}, {"optionKey": 3, "questionId": "cmheik4oq002wjus4igr98wyk"}, {"optionKey": 0, "questionId": "cmheilddv002yjus4vgj773vv"}, {"optionKey": 0, "questionId": "cmheimyub0030jus4sequr6na"}]	2025-11-04 07:27:44.272
cmhk904zj000ljuhzyiu9woqt	cmhj3gkgo00bxjus4teiqpmwk	cmh98n3xn000bjus4t2641bic	2	80	t	[{"optionKey": 1, "questionId": "cmheihsja002sjus45xvghic0"}, {"optionKey": 0, "questionId": "cmheiikjw002ujus46z8mhycv"}, {"optionKey": 2, "questionId": "cmheik4oq002wjus4igr98wyk"}, {"optionKey": 1, "questionId": "cmheilddv002yjus4vgj773vv"}, {"optionKey": 1, "questionId": "cmheimyub0030jus4sequr6na"}]	2025-11-04 07:29:16.351
cmhk9273z000njuhzlekd37gj	cmhj3gkgo00bxjus4teiqpmwk	cmh98zs2c000kjus40tgi0zgj	1	100	t	[{"optionKey": 1, "questionId": "cmhekf76m003ojus4lpp3eza6"}, {"optionKey": 0, "questionId": "cmheki6zo003qjus4ywl6hhsk"}, {"optionKey": 1, "questionId": "cmhekj3dh003sjus4vxcp5djv"}, {"optionKey": 1, "questionId": "cmhekjita003ujus4hze8zw67"}, {"optionKey": 0, "questionId": "cmhekl7ky003wjus47u465xki"}]	2025-11-04 07:30:52.415
cmhk96xpv000pjuhzejpqtb30	cmhj3gkgo00bxjus4teiqpmwk	cmhbuntgs001njus4cf4426d5	1	40	f	[{"optionKey": 2, "questionId": "cmhg6wg0n007ejus42aacqm20"}, {"optionKey": 0, "questionId": "cmhg6wq8g007gjus482tu4p4d"}, {"optionKey": 0, "questionId": "cmhg6xt4e007ijus44ynpth8g"}, {"optionKey": 1, "questionId": "cmhg6z4uo007kjus4v9xarfzo"}, {"optionKey": 0, "questionId": "cmhg70cg9007mjus40wc6ypit"}]	2025-11-04 07:34:33.524
cmhk987il000rjuhzgp0a8dn4	cmhj3gkgo00bxjus4teiqpmwk	cmhbuntgs001njus4cf4426d5	2	60	f	[{"optionKey": 0, "questionId": "cmhg6wg0n007ejus42aacqm20"}, {"optionKey": 0, "questionId": "cmhg6wq8g007gjus482tu4p4d"}, {"optionKey": 0, "questionId": "cmhg6xt4e007ijus44ynpth8g"}, {"optionKey": 1, "questionId": "cmhg6z4uo007kjus4v9xarfzo"}, {"optionKey": 3, "questionId": "cmhg70cg9007mjus40wc6ypit"}]	2025-11-04 07:35:32.877
cmhkccdnf000tjuhz4kl35akr	cmhj2sveo00bsjus4zm3lbtm5	cmhht5ev300bejus4kgumi0vi	1	100	t	[{"optionKey": 1, "questionId": "cmhk8kflj0007juhz95mgm348"}, {"optionKey": 2, "questionId": "cmhk8m8z40009juhzw3pvakif"}, {"optionKey": 2, "questionId": "cmhk8q21l000bjuhzb6fctr0m"}, {"optionKey": 0, "questionId": "cmhk8qjka000djuhzs5rdzxpm"}, {"optionKey": 1, "questionId": "cmhk8r838000fjuhzq0tk2nw8"}]	2025-11-04 09:02:46.299
cmhlopp0v000zjuhz0myyszu6	cmhljp2x3000vjuhzfvgqes6u	cmhbvwu7p002qjus4wd964v8j	1	100	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 1, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-05 07:36:49.136
cmhlw8se50011juhzuinpputw	cmhloo3jh000xjuhzly3m6w5s	cmhbvwu7p002qjus4wd964v8j	1	80	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 3, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-05 11:07:37.275
cmhlwe4gr0013juhz9yntozzf	cmhljnqlx000ujuhz3eqr5nq9	cmhbvwu7p002qjus4wd964v8j	1	100	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 1, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-05 11:11:46.203
cmhlwngyp0015juhzgywzi0af	cmhljnqlx000ujuhz3eqr5nq9	cmhbuisyj001ejus4c4v4urph	1	100	t	[{"optionKey": 1, "questionId": "cmheqnszk006ijus469wgybvy"}, {"optionKey": 0, "questionId": "cmheqo5ix006kjus4jmh0gw31"}, {"optionKey": 1, "questionId": "cmheqp7u9006mjus40g6mz99z"}, {"optionKey": 0, "questionId": "cmheqqfzq006qjus42x4ajotl"}, {"optionKey": 0, "questionId": "cmheqsb1v006sjus4if69qpxu"}]	2025-11-05 11:19:02.306
cmhlwvq6f0017juhzbzd08cb5	cmhljnqlx000ujuhz3eqr5nq9	cmhbuvg3g001wjus4d8oed9ls	1	100	t	[{"optionKey": 3, "questionId": "cmhhqpd9c00aqjus4dher86bu"}, {"optionKey": 0, "questionId": "cmhhqr36900asjus4he7no7df"}, {"optionKey": 0, "questionId": "cmhhqx9be00aujus46fupain3"}, {"optionKey": 0, "questionId": "cmhhqyz6500awjus4dopt6fwr"}, {"optionKey": 0, "questionId": "cmhhr0b8b00ayjus44lzexg7b"}]	2025-11-05 11:25:27.495
cmhlx2mxa0019juhz6q09qetc	cmhljnqlx000ujuhz3eqr5nq9	cmhht5ev300bejus4kgumi0vi	1	100	t	[{"optionKey": 1, "questionId": "cmhk8kflj0007juhz95mgm348"}, {"optionKey": 2, "questionId": "cmhk8m8z40009juhzw3pvakif"}, {"optionKey": 2, "questionId": "cmhk8q21l000bjuhzb6fctr0m"}, {"optionKey": 0, "questionId": "cmhk8qjka000djuhzs5rdzxpm"}, {"optionKey": 1, "questionId": "cmhk8r838000fjuhzq0tk2nw8"}]	2025-11-05 11:30:49.87
cmhlxd7ho001bjuhzfeh7l0h9	cmhljnqlx000ujuhz3eqr5nq9	cmh98n3xn000bjus4t2641bic	1	100	t	[{"optionKey": 1, "questionId": "cmheihsja002sjus45xvghic0"}, {"optionKey": 0, "questionId": "cmheiikjw002ujus46z8mhycv"}, {"optionKey": 2, "questionId": "cmheik4oq002wjus4igr98wyk"}, {"optionKey": 1, "questionId": "cmheilddv002yjus4vgj773vv"}, {"optionKey": 0, "questionId": "cmheimyub0030jus4sequr6na"}]	2025-11-05 11:39:03.084
cmhlxk8mc001djuhzv55isbcv	cmhljnqlx000ujuhz3eqr5nq9	cmh98zs2c000kjus40tgi0zgj	1	100	t	[{"optionKey": 1, "questionId": "cmhekf76m003ojus4lpp3eza6"}, {"optionKey": 0, "questionId": "cmheki6zo003qjus4ywl6hhsk"}, {"optionKey": 1, "questionId": "cmhekj3dh003sjus4vxcp5djv"}, {"optionKey": 1, "questionId": "cmhekjita003ujus4hze8zw67"}, {"optionKey": 0, "questionId": "cmhekl7ky003wjus47u465xki"}]	2025-11-05 11:44:31.141
cmhnb8276001fjuhzbw36zt1g	cmhj2sveo00bsjus4zm3lbtm5	cmh98n3xn000bjus4t2641bic	1	100	t	[{"optionKey": 1, "questionId": "cmheihsja002sjus45xvghic0"}, {"optionKey": 0, "questionId": "cmheiikjw002ujus46z8mhycv"}, {"optionKey": 2, "questionId": "cmheik4oq002wjus4igr98wyk"}, {"optionKey": 1, "questionId": "cmheilddv002yjus4vgj773vv"}, {"optionKey": 0, "questionId": "cmheimyub0030jus4sequr6na"}]	2025-11-06 10:54:43.745
cmhopa2ef001ujuhzax03mbm0	cmhncj5d2001mjuhz3ndb98di	cmhbvwu7p002qjus4wd964v8j	1	100	t	[{"optionKey": 0, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 1, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 1, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-07 10:15:58.118
cmhoph3wx001wjuhzu4n3a0my	cmhncj5d2001mjuhz3ndb98di	cmhbuisyj001ejus4c4v4urph	1	100	t	[{"optionKey": 1, "questionId": "cmheqnszk006ijus469wgybvy"}, {"optionKey": 0, "questionId": "cmheqo5ix006kjus4jmh0gw31"}, {"optionKey": 1, "questionId": "cmheqp7u9006mjus40g6mz99z"}, {"optionKey": 0, "questionId": "cmheqqfzq006qjus42x4ajotl"}, {"optionKey": 0, "questionId": "cmheqsb1v006sjus4if69qpxu"}]	2025-11-07 10:21:26.674
cmhopomgb001yjuhz4f6mctr0	cmhncj5d2001mjuhz3ndb98di	cmhbuvg3g001wjus4d8oed9ls	1	80	t	[{"optionKey": 3, "questionId": "cmhhqpd9c00aqjus4dher86bu"}, {"optionKey": 0, "questionId": "cmhhqr36900asjus4he7no7df"}, {"optionKey": 0, "questionId": "cmhhqx9be00aujus46fupain3"}, {"optionKey": 0, "questionId": "cmhhqyz6500awjus4dopt6fwr"}, {"optionKey": 1, "questionId": "cmhhr0b8b00ayjus44lzexg7b"}]	2025-11-07 10:27:17.291
cmhpxbl790020juhzp7a5o6qq	cmgt7o0gq0000jua6wsrukcnr	cmhbvwu7p002qjus4wd964v8j	1	40	f	[{"optionKey": 1, "questionId": "cmhgf4vc800agjus4e2ohbujq"}, {"optionKey": 3, "questionId": "cmhgf5qmn00aijus4zf1fj8v0"}, {"optionKey": 3, "questionId": "cmhgf6qr400akjus4a354bukj"}, {"optionKey": 2, "questionId": "cmhgf7rio00amjus4gwgh5f1c"}, {"optionKey": 0, "questionId": "cmhgf83dv00aojus4q8g0lmrn"}]	2025-11-08 06:48:52.244
cmhsy1til0022juhz4yx5gi68	cmhloo3jh000xjuhzly3m6w5s	cmhbuisyj001ejus4c4v4urph	1	80	t	[{"optionKey": 1, "questionId": "cmheqnszk006ijus469wgybvy"}, {"optionKey": 0, "questionId": "cmheqo5ix006kjus4jmh0gw31"}, {"optionKey": 0, "questionId": "cmheqp7u9006mjus40g6mz99z"}, {"optionKey": 0, "questionId": "cmheqqfzq006qjus42x4ajotl"}, {"optionKey": 0, "questionId": "cmheqsb1v006sjus4if69qpxu"}]	2025-11-10 09:32:34.603
cmhsypcpr0024juhz0p7n3lu7	cmhloo3jh000xjuhzly3m6w5s	cmhbuvg3g001wjus4d8oed9ls	1	80	t	[{"optionKey": 3, "questionId": "cmhhqpd9c00aqjus4dher86bu"}, {"optionKey": 0, "questionId": "cmhhqr36900asjus4he7no7df"}, {"optionKey": 0, "questionId": "cmhhqx9be00aujus46fupain3"}, {"optionKey": 1, "questionId": "cmhhqyz6500awjus4dopt6fwr"}, {"optionKey": 0, "questionId": "cmhhr0b8b00ayjus44lzexg7b"}]	2025-11-10 09:50:52.576
cmhsytmer0026juhzo98etiha	cmhloo3jh000xjuhzly3m6w5s	cmhht5ev300bejus4kgumi0vi	1	100	t	[{"optionKey": 1, "questionId": "cmhk8kflj0007juhz95mgm348"}, {"optionKey": 2, "questionId": "cmhk8m8z40009juhzw3pvakif"}, {"optionKey": 2, "questionId": "cmhk8q21l000bjuhzb6fctr0m"}, {"optionKey": 0, "questionId": "cmhk8qjka000djuhzs5rdzxpm"}, {"optionKey": 1, "questionId": "cmhk8r838000fjuhzq0tk2nw8"}]	2025-11-10 09:54:11.763
cmhsz1mal0028juhz7gxgj0sl	cmhloo3jh000xjuhzly3m6w5s	cmh98n3xn000bjus4t2641bic	1	80	t	[{"optionKey": 1, "questionId": "cmheihsja002sjus45xvghic0"}, {"optionKey": 0, "questionId": "cmheiikjw002ujus46z8mhycv"}, {"optionKey": 2, "questionId": "cmheik4oq002wjus4igr98wyk"}, {"optionKey": 1, "questionId": "cmheilddv002yjus4vgj773vv"}, {"optionKey": 1, "questionId": "cmheimyub0030jus4sequr6na"}]	2025-11-10 10:00:24.861
cmhsz8a1l002ajuhzs6afe52f	cmhloo3jh000xjuhzly3m6w5s	cmh98zs2c000kjus40tgi0zgj	1	100	t	[{"optionKey": 1, "questionId": "cmhekf76m003ojus4lpp3eza6"}, {"optionKey": 0, "questionId": "cmheki6zo003qjus4ywl6hhsk"}, {"optionKey": 1, "questionId": "cmhekj3dh003sjus4vxcp5djv"}, {"optionKey": 1, "questionId": "cmhekjita003ujus4hze8zw67"}, {"optionKey": 0, "questionId": "cmhekl7ky003wjus47u465xki"}]	2025-11-10 10:05:35.577
cmhszeolo002cjuhzdlxko9ms	cmhloo3jh000xjuhzly3m6w5s	cmhbuntgs001njus4cf4426d5	1	100	t	[{"optionKey": 0, "questionId": "cmhg6wg0n007ejus42aacqm20"}, {"optionKey": 0, "questionId": "cmhg6wq8g007gjus482tu4p4d"}, {"optionKey": 1, "questionId": "cmhg6z4uo007kjus4v9xarfzo"}, {"optionKey": 2, "questionId": "cmhg70cg9007mjus40wc6ypit"}, {"optionKey": 0, "questionId": "cmhg6xt4e007ijus44ynpth8g"}]	2025-11-10 10:10:34.381
cmhszkfq8002ejuhzdpubpaxn	cmhloo3jh000xjuhzly3m6w5s	cmhbv73rp002bjus4b7e84qnc	1	100	t	[{"optionKey": 1, "questionId": "cmhgegi3a009cjus4sfqzvkh4"}, {"optionKey": 0, "questionId": "cmhgegqs4009ejus4tt0vmr27"}, {"optionKey": 1, "questionId": "cmhgehxlo009gjus4ynd5mxj9"}, {"optionKey": 1, "questionId": "cmhgej5yu009ijus41zqcm5bd"}, {"optionKey": 3, "questionId": "cmhgekrfb009kjus42h3vmg8l"}]	2025-11-10 10:15:02.817
cmht1thru002gjuhzjl6vj69v	cmhloo3jh000xjuhzly3m6w5s	cmhbucn5l0015jus4srzatt54	1	100	t	[{"optionKey": 2, "questionId": "cmheq5ccy005mjus4eghmufam"}, {"optionKey": 0, "questionId": "cmheq5tfk005ojus4r8y36u0t"}, {"optionKey": 3, "questionId": "cmheq79ii005qjus43iip6wig"}, {"optionKey": 2, "questionId": "cmheq8ygk005sjus4hxbawun6"}, {"optionKey": 1, "questionId": "cmheq9zo7005ujus486b5yd5c"}]	2025-11-10 11:18:04.602
cmht20w19002ijuhz18qoj5p6	cmhloo3jh000xjuhzly3m6w5s	cmhbuekjz0018jus42kovttsw	1	100	t	[{"optionKey": 2, "questionId": "cmheqc6j1005yjus4byzqp9kz"}, {"optionKey": 0, "questionId": "cmheqclqf0060jus4v0cb25g2"}, {"optionKey": 1, "questionId": "cmheqds6e0062jus468pfplek"}, {"optionKey": 0, "questionId": "cmheqfarj0064jus40kqgzlhj"}, {"optionKey": 1, "questionId": "cmheqg6o90066jus4icevpzyk"}]	2025-11-10 11:23:49.677
cmht26sma002kjuhzpofdh022	cmhloo3jh000xjuhzly3m6w5s	cmhbum86d001kjus4bgbltt4i	1	80	t	[{"optionKey": 3, "questionId": "cmhg6sh4t0074jus4m04qmqke"}, {"optionKey": 0, "questionId": "cmhg6suhu0076jus4s7ja9hh7"}, {"optionKey": 0, "questionId": "cmhg6u2ef0078jus46d2epzc4"}, {"optionKey": 0, "questionId": "cmhg6uhhb007ajus4eevgy9fi"}, {"optionKey": 0, "questionId": "cmhg6uu65007cjus4ckq13amq"}]	2025-11-10 11:28:25.186
cmht2fwh4002mjuhz9aa0hovn	cmhloo3jh000xjuhzly3m6w5s	cmhbtm5vm0012jus4dgwn4hr8	1	100	t	[{"optionKey": 3, "questionId": "cmhenmnlt005cjus4fwh6v0pu"}, {"optionKey": 0, "questionId": "cmhenn061005ejus4eaon2cwy"}, {"optionKey": 2, "questionId": "cmhenobbo005gjus43y5hzvaw"}, {"optionKey": 0, "questionId": "cmhenoutk005ijus4z8v8s11h"}, {"optionKey": 0, "questionId": "cmhenqk1t005kjus4vyalje6g"}]	2025-11-10 11:35:30.088
cmht2mi2h002ojuhziy5a70ru	cmhloo3jh000xjuhzly3m6w5s	cmhbv9hh9002hjus4lgw71w1u	1	100	t	[{"optionKey": 1, "questionId": "cmhgespep009wjus41y1f9ttx"}, {"optionKey": 0, "questionId": "cmhget3sd009yjus436x2upqi"}, {"optionKey": 0, "questionId": "cmhgeu0yg00a0jus4964kr67s"}, {"optionKey": 0, "questionId": "cmhgeue4z00a2jus4viehi3yz"}, {"optionKey": 0, "questionId": "cmhgevxd900a4jus4ds51rhls"}]	2025-11-10 11:40:38.009
\.


--
-- Data for Name: Certificate; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."Certificate" (id, "userId", "issuedAt", "totalScore", "filePath", "mainModuleId") FROM stdin;
\.


--
-- Data for Name: EmployeeMainModuleProgress; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."EmployeeMainModuleProgress" (id, "employeeId", "mainModuleId", "currentSubmoduleIndex", "isCompleted", "completionDate") FROM stdin;
\.


--
-- Data for Name: MainModule; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."MainModule" (id, title, description, "youtubeId", "isActive", "createdDate", "certificateTemplate", "orderIndex") FROM stdin;
7	Sciatica	Understanding Sciatica	81zujcADQ04	t	2025-11-02 14:36:05.275	\N	4
8	Spinal Column	Understanding spinal column	gUG_zbKqlaU	t	2025-11-02 14:37:28.145	\N	5
10	Hypothyroid	\N	S1kdYd4JGbg	t	2025-11-02 14:40:40.358	\N	6
11	Myocardial infarction	\N	jP0qT6GpBVY	t	2025-11-02 14:43:56.807	\N	7
12	Digestion	\N	_T_vmcLyTzI	t	2025-11-02 14:45:23.696	\N	8
13	Diabetes Mellitus	\N	d86DofYpkrY	t	2025-11-02 14:52:13.266	\N	9
1	Immunity	Understand what immunity really means and how your body’s defense system protects you.\nThis video explains the science behind immunity and the fascinating process of how it works within us.	PSRJfaAYkW4	t	2025-10-25 06:31:04.396	\N	1
5	Stress	Learn what stress truly is and how it silently disrupts your body and mind.\nThis video uncovers the hidden havoc stress can cause on your health and overall well-being.	Gn5NaUnScHk	t	2025-10-27 14:34:00.79	\N	2
6	Osteoarthritis	Understand the changes that occur within the bone during osteoarthritis — how degeneration, inflammation, and structural remodeling lead to pain, stiffness, and reduced joint function.	EYthXscYkxQ	t	2025-11-02 14:34:28.36	\N	3
14	Piles	Piles (Hemorrhoids) – swollen veins in the rectal area causing pain, bleeding, and discomfort during bowel movements. With Ayurvedic care, lifestyle correction, and herbal remedies, piles can be effectively managed and recurrence prevented.	PbSduiKnnRs	t	2025-11-02 14:58:37.632	\N	10
15	Renal Calculi	Renal Calculi (Kidney Stones) – hard mineral deposits formed in the kidneys causing severe pain, burning urination, or urinary obstruction. Ayurvedic herbs like Pashanabheda, Varuna, and Gokshura help dissolve stones, ease discomfort, and support healthy kidney function naturally.	xmbpPWIV0VU	t	2025-11-02 15:00:47.863	\N	11
16	Infertility	\N	qKAOkYMycH4	t	2025-11-02 15:05:37.194	\N	12
17	Understanding Neurotransmission	\N	hGDvvUNU-cw	t	2025-11-02 15:15:00.159	\N	13
18	Menstrual cramps	\N	5u6Y6ZP2_Wg	t	2025-11-02 15:17:02.112	\N	14
19	Blood pressure	\N	2HTZs51OYwo	t	2025-11-02 15:21:03.496	\N	15
20	Role of minerals	\N	uZousR_FfEE	t	2025-11-02 15:23:48.423	\N	16
21	Swarna Prashana	\N	edFqsnYx3sA	t	2025-11-02 15:36:14.782	\N	17
22	Skin health	\N	Nq7AUoCRo3c	t	2025-11-02 15:37:14.072	\N	18
\.


--
-- Data for Name: Module; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."Module" (id, "order", title, description, "youtubeId", published, "createdAt", "updatedAt", "mainModuleId", "orderWithinMain") FROM stdin;
cmh991vo2000ljus4wuczvof9	5	Mehon	Mehon is an Ayurvedic formulation specially designed to support healthy blood sugar levels and metabolic balance. It helps improve insulin function, reduces fatigue, and promotes overall well-being in diabetic individuals.	XgS1ae_s0jE	t	2025-10-27 14:45:09.65	2025-11-02 15:22:06.245	13	1
cmhbutxdz001rjus4i2jddkpq	19	Panchavalkala Kwatha	Panchavalkala Kwatha is a classical Ayurvedic decoction known for its powerful wound-healing and anti-inflammatory properties. It helps cleanse wounds, soothe skin irritations, and promote healthy tissue regeneration.	7B7_zQhYp8o	t	2025-10-29 10:30:22.535	2025-11-02 15:22:06.274	14	2
cmhbuhv7b0019jus4rbdenk57	13	Lohiron	Lohiron is an Ayurvedic iron supplement formulated to combat anemia and boost hemoglobin levels naturally. It improves vitality, reduces fatigue, and supports healthy blood formation without gastric discomfort.	HBvCiQyAwvg	t	2025-10-29 10:20:59.831	2025-11-02 15:24:23.45	20	1
cmhbum86b001ijus4mp4faa0g	16	Thyrovib	Thyrovib is an Ayurvedic formulation that supports healthy thyroid function and hormonal balance. It helps manage symptoms of hypothyroidism such as fatigue, weight gain, and low metabolism naturally.	jh5JnGconzo	t	2025-10-29 10:24:23.268	2025-11-02 15:22:06.269	10	1
cmh99dn56000ojus4bfxenktn	6	Swarna Madhumeha Sanjeevini Ras	Swarna Madhumeha Sanjeevini Ras is a potent Ayurvedic herbo-mineral formulation for managing diabetes naturally.\nIt helps regulate blood sugar levels, revitalizes pancreatic function, and supports overall metabolic health.	Gev8WSXbOvY	t	2025-10-27 14:54:18.474	2025-11-02 15:22:06.247	13	3
cmhbt2moh000rjus4zvnsxk9f	7	Alka Veda Syrup	Alka Veda Syrup is a natural Ayurvedic formulation that alkalizes the urinary system and supports kidney health. It helps dissolve kidney stones, relieve burning micturition, and restore urinary pH balance.	w31StUDGrrs	t	2025-10-29 09:41:09.328	2025-11-02 15:22:06.248	15	2
cmhbuvg3d001ujus461a5o7yw	20	Chiramol	Chiramol is an Ayurvedic formulation effective in managing fever and inflammatory conditions.\nIt helps reduce body ache, fatigue, and fever while restoring energy and overall well-being.	TnDI86HDU6U	t	2025-10-29 10:31:33.434	2025-11-02 15:22:06.276	1	3
cmhbte1av000ujus4rmmrluk4	8	Ashmagone Tablet	Ashmagone Tablet is an Ayurvedic formulation specially crafted to manage renal calculi and urinary tract disorders. It aids in dissolving stones, easing pain, and promoting smooth urinary flow.	yKvl4m4M-l4	t	2025-10-29 09:50:01.495	2025-11-02 15:22:06.251	15	1
cmh98wlat000fjus4fn1buajs	3	Taruni Rakshya Syrup	Taruni Rakshya Syrup is a unique Ayurvedic formulation designed to support women’s reproductive health and hormonal balance. It helps regulate menstrual cycles, reduce discomfort, and promote overall uterine wellness.	ftZJRamhP9g	t	2025-10-27 14:41:02.934	2025-11-02 15:22:06.241	18	1
cmhbtfjne000xjus4323d3qnv	9	Normo - HT	Normo HT is an Ayurvedic formulation that helps maintain healthy blood pressure and supports cardiovascular balance. It improves circulation and promotes overall heart wellness naturally.	7RedeiGC4ZU	t	2025-10-29 09:51:11.93	2025-11-02 15:22:06.254	19	1
cmhbtm5vi0010jus4nkytbce9	10	Cardorium plus - Ayurvedaone	Cardorium Plus is a trusted Ayurvedic formulation that supports heart health and helps regulate cholesterol levels naturally. It enhances blood circulation, strengthens cardiac function, and promotes overall cardiovascular well-being.	51Zs7n_F-3U	t	2025-10-29 09:56:20.671	2025-11-02 15:22:06.256	11	1
cmh98zs29000ijus4vc4ns8em	4	Calmukti	Calmukti Tablet is an Ayurvedic blend formulated to relieve stress, anxiety, and mental fatigue naturally. 	6i-bjHy9x5U	t	2025-10-27 14:43:31.666	2025-11-02 15:22:06.243	5	2
cmh98n3xk0009jus4ui0frx5m	1	Nidron	Nidron is a natural Ayurvedic formulation that promotes restful sleep, calms the mind, and relieves anxiety.\nIt helps restore healthy sleep patterns without causing dependence or daytime drowsiness.	RBHleUPsrek	t	2025-10-27 14:33:40.521	2025-11-02 15:22:06.237	5	1
cmhbuntgq001ljus478vhzwp1	17	Strong Joint	Strong Joint is an Ayurvedic formulation that nourishes cartilage and strengthens joints for better mobility. It helps reduce inflammation, relieve pain, and support long-term joint health and flexibility.	YS_CmWqoeLk	t	2025-10-29 10:25:37.515	2025-11-02 15:24:11.992	6	1
cmhbv73rn0029jus4meo8nn2u	25	Vitabin M 	Vitabin-M is a unique blend that supports energy, immunity, and bone health. It helps combat fatigue, strengthens muscles, and promotes overall vitality and well-being. 	X-gqlFdgiuk	t	2025-10-29 10:40:37.332	2025-11-02 15:24:11.996	6	2
cmhbusxqm001ojus4ou9j4r2r	18	Kalcium n	Kalcium-N is an Ayurvedic calcium supplement that strengthens bones and teeth naturally. It supports healthy bone density, aids fracture healing, and promotes overall musculoskeletal wellness.	MTK5tasvt-Y	t	2025-10-29 10:29:36.335	2025-11-02 15:24:23.452	20	2
cmhbulahk001fjus4rpttdlhu	15	Laxcef 	Laxcef is a broad-spectrum Ayurvedic-supported antimicrobial formulation designed to fight bacterial infections effectively. It helps relieve symptoms of respiratory, urinary, and skin infections while supporting faster recovery.	p6JlgOgKAeo	t	2025-10-29 10:23:39.608	2025-11-02 15:25:10.073	12	3
cmhbuekjx0016jus4kl22t0xl	12	Spondolord	Spondolord is an Ayurvedic formulation designed to relieve neck and back stiffness associated with spondylosis. It reduces inflammation, strengthens joints, and restores spinal flexibility naturally	gGj7lj1UVDU	t	2025-10-29 10:18:26.061	2025-11-02 15:24:50.976	8	1
cmhbuxl95001xjus40y3mn0u4	21	Swarna Sekhara Rasa	Swarna Sekhara Rasa is a blend of classical Ayurvedic herbo-mineral formulation used to manage indigestion, pitta ailments, and acidity. It strengthens and enhances digestion, and promotes overall vitality and resilience.	FaDjDupWz9s	t	2025-10-29 10:33:13.434	2025-11-02 15:25:10.074	12	4
cmhbv0zd50020jus41qmurywm	22	Shishu Kalyan Rasa	Shishu Kalyan Rasa is a blend of classical Ayurvedic formulations that supports healthy growth, immunity, and development in children. It aids in digestion, enhances strength, and helps children attain their developmental milestones naturally.	IXRD1ikVBSM	t	2025-10-29 10:35:51.689	2025-11-02 15:36:22.888	21	1
cmhbv4ti90026jus4yf5whuyz	24	Laxloma - Ayurvibes	Laxloma is an Ayurvedic formulation that promotes smooth and regular bowel movements.\nIt relieves constipation, bloating, and indigestion while supporting healthy digestion and detoxification.	Q8FaIV8M-EM	t	2025-10-29 10:38:50.721	2025-11-02 15:25:10.071	12	2
cmhbv39mm0023jus4ejws4116	23	Tatvam HB	Tatvam HB is an Ayurvedic formulation designed to manage various skin disorders and purify the blood. It helps reduce acne, itching, and pigmentation while promoting clear, healthy, and radiant skin.	Nq7AUoCRo3c	t	2025-10-29 10:37:38.303	2025-11-02 15:37:51.072	22	1
cmh98vb7g000cjus4b38uu9r1	2	Brihatri chintamani ras	Brihatri Chintamani Ras is a Ayurvedic herbo-mineral formulation that rejuvenates the body and strengthens vital organs.	9Lmiim1ykb0	t	2025-10-27 14:40:03.197	2025-11-03 08:16:04.254	17	1
cmhbucn5h0013jus4ds8swhpv	11	Nurall	Nurall is an Ayurvedic formulation that nourishes the nervous system and supports mental clarity. It helps promotes overall neurological well-being.	IL8SyBxPEKw	t	2025-10-29 10:16:56.118	2025-11-03 08:16:12.026	7	1
cmhbvaovq002ijus4cw8w6mqf	28	Flatula O Syrup	Flatula-O Syrup is an Ayurvedic formulation that relieves gas, bloating, and abdominal discomfort. It improves digestion, reduces flatulence, and promotes a light, comfortable feeling after meals.	7zld39Ie6G4	t	2025-10-29 10:43:24.663	2025-11-02 15:25:10.07	12	1
cmhhs4fwp00azjus4m7vppmkt	31	Madhuhara churna	Madhuhara Churna — a natural Ayurvedic blend that helps regulate blood sugar levels and supports healthy metabolism. Promotes pancreatic health, boosts energy, and aids in long-term glycemic balance naturally.	n6UbEOYh0eE	t	2025-11-02 14:01:11.306	2025-11-03 08:10:15.75	13	2
cmhbuisyg001cjus4b9ctt29g	14	Eeez AR	Eeez-AR is an Ayurvedic formulation that provides effective relief from allergic rhinitis and seasonal allergies. It helps reduce sneezing, nasal congestion, and watery discharge while strengthening respiratory immunity.	XQZ7jY52cOk	t	2025-10-29 10:21:43.577	2025-11-02 15:22:06.264	1	2
cmhbv8ccn002cjus4ystimx3h	26	Pilafar	Pilafar is an Ayurvedic formulation specially designed for the management of hemorrhoids (piles). It helps reduce pain, swelling, and bleeding while promoting smooth bowel movements and rectal healing.	3S6eGt3lB4A	t	2025-10-29 10:41:35.111	2025-11-02 15:22:06.286	14	1
cmhbv9hh7002fjus4o9ejb0np	27	Lipidof Combo	Lipidof Combo is an Ayurvedic formulation that helps regulate cholesterol and triglyceride levels naturally.\nIt supports healthy lipid metabolism, improves circulation, and promotes overall cardiovascular wellness.	FZDBOsfhdRU	t	2025-10-29 10:42:28.411	2025-11-02 15:22:06.287	11	2
cmhbvq3uo002ljus4me2p1en7	29	Vajeevan	Vajeevan Lehya is a powerful Ayurvedic rejuvenator that enhances stamina, strength, and vitality in men. It nourishes body tissues, boosts energy, and supports overall reproductive health naturally.	HyGIjfjEPpw	t	2025-10-29 10:55:23.904	2025-11-02 15:22:06.29	16	1
cmhbvwu7m002ojus42y0pd3qh	30	Immunoj	Immunoj is an Ayurvedic formulation that strengthens the body’s natural defense system and enhances immunity. It helps protect against recurrent infections and promotes overall health and resilience. 	oJ-F6PxeVb4	t	2025-10-29 11:00:38.002	2025-11-02 15:22:06.291	1	1
cmhht5ev000bcjus4mc5ay8ve	32	Shilajit	Shilajit – a powerful Ayurvedic rejuvenator sourced from the Himalayas, rich in fulvic acid and essential minerals. Enhances energy, stamina, and vitality while supporting mental clarity and overall well-being.	JH9Vga9q89E	t	2025-11-02 14:29:56.221	2025-11-02 15:22:06.294	1	4
cmhhukx8e00bfjus4pscyib31	33	Fertivibes	Fertivibes – an Ayurvedic formulation designed to support reproductive health and enhance fertility in both men and women. Enriched with rejuvenating herbs that balance hormones, strengthen vitality, and promote natural conception.	9pLfrDGcUm8	t	2025-11-02 15:09:59.486	2025-11-02 15:22:06.296	16	2
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."Question" (id, "quizId", text, options, "correctIndex", active, "correctAnswer", "optionA", "optionB", "optionC", "optionD", "orderIndex", "questionType") FROM stdin;
cmheihsja002sjus45xvghic0	cmh98n3xn000bjus4t2641bic	What is the primary benefit of Nidron?	{"Enhances digestion and bowel regularity","Promotes sound, restful sleep, reduces stress, and addresses sleep disorders naturally","Supports thyroid hormone balance","Lowers high cholesterol and lipids"}	1	t	B	Enhances digestion and bowel regularity	Promotes sound, restful sleep, reduces stress, and addresses sleep disorders naturally	Supports thyroid hormone balance	Lowers high cholesterol and lipids	\N	MCQ_4
cmheiikjw002ujus46z8mhycv	cmh98n3xn000bjus4t2641bic	Tagara (Valeriana wallichii) in Nidron helps induce sleep, relieves anxiety, and relaxes the nervous system	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheik4oq002wjus4igr98wyk	cmh98n3xn000bjus4t2641bic	Which ingredient in Nidron is a natural antidepressant and neuro-stimulant that balances mood and promotes restorative sleep?	{Ashwagandha,Brahmi,"Jatamamsi (Nardostachys jatamansi)",Tagara}	2	t	C	Ashwagandha	Brahmi	Jatamamsi (Nardostachys jatamansi)	Tagara	\N	MCQ_4
cmheilddv002yjus4vgj773vv	cmh98n3xn000bjus4t2641bic	If a pack of Nidron costs ₹234 and contains 30 tablets, approximately how much does each tablet cost?	{₹7,₹8,₹6,₹10}	1	t	B	₹7	₹8	₹6	₹10	\N	MCQ_4
cmheimyub0030jus4sequr6na	cmh98n3xn000bjus4t2641bic	What is the recommended adult dose of Nidron?	{"1–2 tablets at bedtime daily","1–2 tablets twice daily after food","5 ml twice daily","1 teaspoon before food"}	0	t	A	1–2 tablets at bedtime daily	1–2 tablets twice daily after food	5 ml twice daily	1 teaspoon before food	\N	MCQ_4
cmheirlib0032jus4jyndcvml	cmh98vb7m000ejus4ug87986n	What is the primary therapeutic benefit of Brihatri Chintamani Rasa?	{"Supports thyroid function naturally","Strengthens the nervous system, improves vitality, and provides neuroprotective support","Lowers cholesterol and triglycerides","Manages allergic rhinitis and sinusitis"}	1	t	B	Supports thyroid function naturally	Strengthens the nervous system, improves vitality, and provides neuroprotective support	Lowers cholesterol and triglycerides	Manages allergic rhinitis and sinusitis	\N	MCQ_4
cmhejnwi00034jus4o1cxw8ln	cmh98vb7m000ejus4ug87986n	Maha Vatavidhwamsa Rasa in Brihatri Chintamani Rasa balances Vata dosha and relieves pain, paralysis, and neuromuscular weakness.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhejp5do0036jus4oku1a103	cmh98vb7m000ejus4ug87986n	Which component in Brihatri Chintamani Rasa acts as a bioavailability enhancer and aids digestion?	{"Shuddha Guggulu",Triphala,Trikatu,Chitraka}	2	t	C	Shuddha Guggulu	Triphala	Trikatu	Chitraka	\N	MCQ_4
cmhejq4350038jus4xrwkieh0	cmh98vb7m000ejus4ug87986n	A medical representative claims that each tablet of Brihatri Chintamani Rasa (MRP ₹899 for 30 tablets) costs ₹35. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhejrakx003ajus4utm1g2aw	cmh98vb7m000ejus4ug87986n	What is the recommended dose of Brihatri Chintamani Rasa for adults?	{"1–2 tablets twice daily, or as directed by the physician","5 ml twice daily","1 tablet at bedtime only","10 g twice daily"}	0	t	A	1–2 tablets twice daily, or as directed by the physician	5 ml twice daily	1 tablet at bedtime only	10 g twice daily	\N	MCQ_4
cmhejtyer003cjus4hjt39zyp	cmh98wlaw000hjus48ipygiip	What is the main therapeutic purpose of Taruni Rakshya Syrup?	{"Improves digestion and liver function","Supports women’s reproductive and hormonal health, relieves menstrual cramps, PMS, and fatigue","Alkalizes the urinary system and prevents kidney stones","Reduces fever and body pain"}	1	t	B	Improves digestion and liver function	Supports women’s reproductive and hormonal health, relieves menstrual cramps, PMS, and fatigue	Alkalizes the urinary system and prevents kidney stones	Reduces fever and body pain	\N	MCQ_4
cmhejvio2003ejus4zbw3j610	cmh98wlaw000hjus48ipygiip	Ashoka (Saraca indica) in Taruni Rakshya Syrup acts as a uterine tonic and helps regulate menstrual flow.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhejyrnw003gjus4gxc861wd	cmh98wlaw000hjus48ipygiip	Which ingredient in Taruni Rakshya Syrup is primarily added to reduce stress and boost energy?	{Shatavari,Ashwagandha,Lodhra,Dashamoola}	1	t	B	Shatavari	Ashwagandha	Lodhra	Dashamoola	\N	MCQ_4
cmhejzqf3003ijus4ukdnbcse	cmh98wlaw000hjus48ipygiip	If a 200 ml bottle of Taruni Rakshya Syrup costs ₹199, approximately how much does 10 ml cost?	{₹5,₹10,₹9.95,₹15}	1	t	B	₹5	₹10	₹9.95	₹15	\N	MCQ_4
cmhek0u27003mjus49k7c51ht	cmh98wlaw000hjus48ipygiip	The syrup can be taken more than 10 ml at a time without consulting a physician.	{TRUE,FALSE}	1	t	FALSE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhekf76m003ojus4lpp3eza6	cmh98zs2c000kjus40tgi0zgj	What is the primary benefit of Calmukti?	{"Improves digestion and detoxification","Reduces stress and anxiety, supports blood circulation, and helps manage mild to moderate hypertension","Enhances male fertility and stamina","Manages thyroid hormone balance"}	1	t	B	Improves digestion and detoxification	Reduces stress and anxiety, supports blood circulation, and helps manage mild to moderate hypertension	Enhances male fertility and stamina	Manages thyroid hormone balance	\N	MCQ_4
cmheki6zo003qjus4ywl6hhsk	cmh98zs2c000kjus40tgi0zgj	Jatamansi (Nardostachys jatamansi) in Calmukti acts as an adaptogen, regulating cortisol and calming the mind.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhekj3dh003sjus4vxcp5djv	cmh98zs2c000kjus40tgi0zgj	Which ingredient in Calmukti is neuroprotective and enhances mental clarity while reducing anxiety?	{Ashwagandha,Brahmi,Shankhapushpi,Sarpagandha}	1	t	B	Ashwagandha	Brahmi	Shankhapushpi	Sarpagandha	\N	MCQ_4
cmhekjita003ujus4hze8zw67	cmh98zs2c000kjus40tgi0zgj	If a pack of Calmukti (30 tablets) costs ₹206, a sales rep tells a customer that each tablet costs ₹8. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhekl7ky003wjus47u465xki	cmh98zs2c000kjus40tgi0zgj	What is the recommended adult dose of Calmukti?	{"1–2 tablets twice daily","5 ml twice daily","10 g twice daily","1 tablet at bedtime"}	0	t	A	1–2 tablets twice daily	5 ml twice daily	10 g twice daily	1 tablet at bedtime	\N	MCQ_4
cmhengq0s0058jus4n0wyablz	cmhbtfjni000zjus4znysa68n	A sales rep tells a customer that each tablet of Normo HT (MRP ₹600 for 100 tablets) costs ₹5.50. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhel5z9n003yjus4qo5wb140	cmh991vo4000njus4ukk2o5zn	What is the main therapeutic benefit of Mehon?	{"Supports thyroid function and metabolism","Relieves constipation and detoxifies the body","Manages Type 2 Diabetes Mellitus, balances blood sugar, and prevents complications naturally","Enhances male fertility and libido"}	2	t	C	Supports thyroid function and metabolism	Relieves constipation and detoxifies the body	Manages Type 2 Diabetes Mellitus, balances blood sugar, and prevents complications naturally	Enhances male fertility and libido	\N	MCQ_4
cmhel6gwb0040jus400kwscnf	cmh991vo4000njus4ukk2o5zn	Vijayasara (Pterocarpus marsupium) in Mehon helps reduce blood glucose and supports pancreatic health.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhel7yl50042jus493ans03p	cmh991vo4000njus4ukk2o5zn	Which herb in Mehon improves insulin sensitivity and helps control post-meal glucose spikes?	{Shilajit,Amalaki,Saptachakra,Vijayasara}	2	t	C	Shilajit	Amalaki	Saptachakra	Vijayasara	\N	MCQ_4
cmhel8lj90044jus4cmdv7fs4	cmh991vo4000njus4ukk2o5zn	A sales rep tells a customer that each capsule of Mehon (MRP ₹563 for 100 capsules) costs ₹6. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhel91zg0046jus486mzdqk5	cmh991vo4000njus4ukk2o5zn	Recommended adult dose is 1–2 capsules twice daily before food.	{Correct,Incorrect}	0	t	A	\N	Incorrect	\N	\N	\N	MCQ_2
cmhelahwm0048jus4hbmyjyq7	cmh99dn5b000qjus4avmfpfk2	What is the primary therapeutic benefit of Swarna Madhumeha Sanjeevani Rasa?	{"Supports thyroid function naturally","Manages Type II Diabetes and its complications, regulates blood glucose, and enhances metabolism","Relieves stress and anxiety","Improves fertility in females"}	0	t	A	Supports thyroid function naturally	Manages Type II Diabetes and its complications, regulates blood glucose, and enhances metabolism	Relieves stress and anxiety	Improves fertility in females	\N	MCQ_4
cmhelavm5004ajus4st0lti6w	cmh99dn5b000qjus4avmfpfk2	Vijayasara (Pterocarpus marsupium) in this formulation enhances insulin secretion and lowers blood sugar.	{Correct,Incorrect}	0	t	A	\N	Incorrect	\N	\N	\N	MCQ_2
cmhelbcsg004cjus42n0odfdn	cmh99dn5b000qjus4avmfpfk2	Vijayasara (Pterocarpus marsupium) in this formulation enhances insulin secretion and lowers blood sugar.	{True,False}	0	t	A	\N	False	\N	\N	\N	MCQ_2
cmhelcthp004ejus4diplwikh	cmh99dn5b000qjus4avmfpfk2	Which ingredient acts as a classical Ayurvedic decoction balancing Kapha and improving digestion in this formulation?	{"Asanadi Kashaya Ghana","Shuddha Shilajit","Vasanta Kusumakara Rasa","Nimba Panchanga Ghana"}	0	t	A	Asanadi Kashaya Ghana	Shuddha Shilajit	Vasanta Kusumakara Rasa	Nimba Panchanga Ghana	\N	MCQ_4
cmhele0fe004gjus455832g44	cmh99dn5b000qjus4avmfpfk2	A medical representative states that each tablet of Swarna Madhumeha Sanjeevani Rasa (MRP ₹890 for 30 tablets) costs ₹35. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhen3gz2004ijus49uo3se04	cmhbt2mox000tjus44peic7ao	What is the main benefit of Alka Veda Syrup?	{"Improves digestion and liver function","Alkalizes the urinary system, reduces stones, and soothes inflammation","Relieves constipation and bloating","Lowers blood sugar and supports pancreas health"}	1	t	B	Improves digestion and liver function	Alkalizes the urinary system, reduces stones, and soothes inflammation	Relieves constipation and bloating	Lowers blood sugar and supports pancreas health	\N	MCQ_4
cmhen3x7w004kjus484imzeyq	cmhbt2mox000tjus44peic7ao	Pashanabheda in Alka Veda Syrup acts as a litholytic, helping break down kidney stones	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhen67m8004mjus4myoq91n0	cmhbt2mox000tjus44peic7ao	Which ingredient in Alka Veda Syrup serves as a natural urinary alkalizer?	{"Shadanga Paniya",Punarnava,Yavakshara,Varuna}	2	t	C	Shadanga Paniya	Punarnava	Yavakshara	Varuna	\N	MCQ_4
cmhen716p004ojus4d5qa8eio	cmhbt2mox000tjus44peic7ao	The MRP of a 200 ml bottle is ₹187. Someone says the price per ml is ₹1.20. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhen84bn004qjus423sy790p	cmhbt2mox000tjus44peic7ao	Recommended dose of Alka Veda Syrup is 10 ml twice daily after meals.	{Yes,No}	0	t	A	\N	No	\N	\N	\N	MCQ_2
cmhena37i004sjus47ygjlhzf	cmhbte1b3000wjus4a2l81p46	What is the primary action of AshmagOne?	{"Improves digestion and appetite","Relieves constipation and bloating","Reduces fever and body pain","Dissolves urinary stones and supports healthy urinary flow"}	3	t	D	Improves digestion and appetite	Relieves constipation and bloating	Reduces fever and body pain	Dissolves urinary stones and supports healthy urinary flow	\N	MCQ_4
cmhenaka5004ujus44mcotdwi	cmhbte1b3000wjus4a2l81p46	Pashanabheda (Bergenia ligulata) helps in breaking down kidney stones.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhenbujp004wjus4vrjgc7dx	cmhbte1b3000wjus4a2l81p46	Which ingredient in AshmagONE acts as a natural diuretic and soothes urinary tract inflammation?	{Gokshura,Jayapala,Bibhitaki,Sonamukhi}	0	t	A	Gokshura	Jayapala	Bibhitaki	Sonamukhi	\N	MCQ_4
cmhencrqv004yjus4d7pna1ww	cmhbte1b3000wjus4a2l81p46	The MRP of AshmagOne pack (30 tablets) is ₹468. Someone claims the price per tablet is ₹12. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhend5n40050jus48uf7qmnu	cmhbte1b3000wjus4a2l81p46	Recommended adult dose of AshmagONE is 1–2 tablets twice daily after meals.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhenet9w0052jus4y3gmoztj	cmhbtfjni000zjus4znysa68n	What is the primary therapeutic benefit of Normo HT?	{"Improves digestion and detoxification","Reduces hypertension naturally, strengthens the heart, and relieves stress","Supports fertility and reproductive health","Manages thyroid hormone balance"}	1	t	B	Improves digestion and detoxification	Reduces hypertension naturally, strengthens the heart, and relieves stress	Supports fertility and reproductive health	Manages thyroid hormone balance	\N	MCQ_4
cmhenf8w90054jus4m0fke8b3	cmhbtfjni000zjus4znysa68n	Sarpagandha (Rauwolfia serpentina) in Normo HT acts as a classical antihypertensive and helps calm anxiety.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheng9j60056jus4ttfhy5rx	cmhbtfjni000zjus4znysa68n	Which ingredient in Normo HT is a natural source of calcium and helps reduce stress-related hypertension?	{Triphala,"Muktashukti Bhasma","Rasayan Churna",Tagara}	1	t	B	Triphala	Muktashukti Bhasma	Rasayan Churna	Tagara	\N	MCQ_4
cmhenj17n005ajus4lpvu63l0	cmhbtfjni000zjus4znysa68n	Recommended adult dose of Normo HT is:	{"1–2 tablets twice daily","5 ml twice daily","1 tablet at bedtime","10 g twice daily after food"}	0	t	A	1–2 tablets twice daily	5 ml twice daily	1 tablet at bedtime	10 g twice daily after food	\N	MCQ_4
cmhenmnlt005cjus4fwh6v0pu	cmhbtm5vm0012jus4dgwn4hr8	What is the primary therapeutic benefit of Cardorium Plus?	{"Relieves constipation and improves digestion","Manages thyroid hormone balance","Enhances male fertility and libido","Supports heart health by improving blood circulation, disintegrating arterial blocks, and lowering cardiovascular risk"}	3	t	D	Relieves constipation and improves digestion	Manages thyroid hormone balance	Enhances male fertility and libido	Supports heart health by improving blood circulation, disintegrating arterial blocks, and lowering cardiovascular risk	\N	MCQ_4
cmhenn061005ejus4eaon2cwy	cmhbtm5vm0012jus4dgwn4hr8	Arjuna (Terminalia arjuna) in Cardorium Plus strengthens cardiac muscles and protects the heart from ischemic damage.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhenobbo005gjus43y5hzvaw	cmhbtm5vm0012jus4dgwn4hr8	Which ingredient in Cardorium Plus helps lower lipid and cholesterol levels, reducing the risk of heart block?	{Kurubaka,Pushkaramoola,Vrikshamla,Gokshura}	2	t	C	Kurubaka	Pushkaramoola	Vrikshamla	Gokshura	\N	MCQ_4
cmhenoutk005ijus4z8v8s11h	cmhbtm5vm0012jus4dgwn4hr8	A chemist claims that each ml of Cardorium Plus (MRP ₹422 for 300 ml) costs ₹2. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhenqk1t005kjus4vyalje6g	cmhbtm5vm0012jus4dgwn4hr8	What is the recommended adult dose of Cardorium Plus?	{"10 ml twice daily","1–2 capsules twice daily","1 teaspoon before bedtime","5 ml once daily"}	0	t	A	10 ml twice daily	1–2 capsules twice daily	1 teaspoon before bedtime	5 ml once daily	\N	MCQ_4
cmheq5ccy005mjus4eghmufam	cmhbucn5l0015jus4srzatt54	Which ingredient in Nurall is rich in L-Dopa and supports dopamine levels?	{"Dashamoola Kashaya","Guggulu (Commiphora mukul)","Kapikacchu (Mucuna pruriens)","Brihat Vata Chintamani"}	2	t	C	Dashamoola Kashaya	Guggulu (Commiphora mukul)	Kapikacchu (Mucuna pruriens)	Brihat Vata Chintamani	\N	MCQ_4
cmheq5tfk005ojus4r8y36u0t	cmhbucn5l0015jus4srzatt54	Dashamoola Kashaya in Nurall helps restore nerve conduction and aids motor recovery.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheq79ii005qjus43iip6wig	cmhbucn5l0015jus4srzatt54	Nurall is indicated in all of the following conditions except:	{"Hemiplegia and paraplegia",Sciatica,"Painful neuropathic disorders","Diabetes mellitus (as a primary indication)"}	3	t	D	Hemiplegia and paraplegia	Sciatica	Painful neuropathic disorders	Diabetes mellitus (as a primary indication)	\N	MCQ_4
cmheq8ygk005sjus4hxbawun6	cmhbucn5l0015jus4srzatt54	The recommended dosage of Nurall is:	{"1 capsule once daily","2 capsules twice daily","1 capsule twice daily","1 capsule once daily"}	2	t	C	1 capsule once daily	2 capsules twice daily	1 capsule twice daily	1 capsule once daily	\N	MCQ_4
cmheq9zo7005ujus486b5yd5c	cmhbucn5l0015jus4srzatt54	Price per capsule of Nurall is approximately:	{₹7.50,₹7.82,₹8.50,₹9.00}	1	t	B	₹7.50	₹7.82	₹8.50	₹9.00	\N	MCQ_4
cmheqc6j1005yjus4byzqp9kz	cmhbuekjz0018jus42kovttsw	Which ingredient in Spondolord is a classical herbomineral tonic with gold that strengthens nerves and enhances mobility?	{"Mahavatavidhwamsa Rasa","Mahayogaraja Guggulu","Rasaraja Rasa","Trayodashang Guggulu"}	2	t	C	Mahavatavidhwamsa Rasa	Mahayogaraja Guggulu	Rasaraja Rasa	Trayodashang Guggulu	\N	MCQ_4
cmheqclqf0060jus4v0cb25g2	cmhbuekjz0018jus42kovttsw	Nirgundi Ghana in Spondolord acts as a potent anti-inflammatory herb that reduces pain and stiffness.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheqds6e0062jus468pfplek	cmhbuekjz0018jus42kovttsw	Spondolord is primarily indicated in:	{"Migraine headaches","Cervical & lumbar spondylosis","Gastritis and hyperacidity","Skin rashes"}	1	t	B	Migraine headaches	Cervical & lumbar spondylosis	Gastritis and hyperacidity	Skin rashes	\N	MCQ_4
cmheqfarj0064jus40kqgzlhj	cmhbuekjz0018jus42kovttsw	The recommended dosage of Spondolord is:	{"1–2 tablets daily after food","1 tablet before meals","2 tablets three times daily","1 tablet every alternate day"}	0	t	A	1–2 tablets daily after food	1 tablet before meals	2 tablets three times daily	1 tablet every alternate day	\N	MCQ_4
cmheqg6o90066jus4icevpzyk	cmhbuekjz0018jus42kovttsw	The approximate price per tablet of Spondolord is:	{₹15.00,₹15.62,₹16.00,₹14.50}	1	t	B	₹15.00	₹15.62	₹16.00	₹14.50	\N	MCQ_4
cmheqhpdt0068jus4nqhs187j	cmhbuhv7e001bjus4zeld0koz	What is the primary benefit of Lohiron?	{"Reduces stress and anxiety","Supports healthy haemoglobin levels, combats anemia, and improves blood quality","Manages blood pressure naturally","Supports thyroid hormone balance"}	1	t	B	Reduces stress and anxiety	Supports healthy haemoglobin levels, combats anemia, and improves blood quality	Manages blood pressure naturally	Supports thyroid hormone balance	\N	MCQ_4
cmheqi2sl006ajus4aftxeqq7	cmhbuhv7e001bjus4zeld0koz	Mandoora Vataka in Lohiron is a classical iron-rich formulation that boosts haemoglobin and iron levels.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheqk8z1006cjus4ktx9vqok	cmhbuhv7e001bjus4zeld0koz	Which component in Lohiron enhances absorption and strengthens blood health when processed with Bhringaraja Swarasa, Amalaki Swarasa, and Shigru Swarasa?	{Loha,"Mandoora Vataka",Triphala,"Shigru Extract"}	1	t	B	Loha	Mandoora Vataka	Triphala	Shigru Extract	\N	MCQ_4
cmheqkqk4006ejus457627ty6	cmhbuhv7e001bjus4zeld0koz	A medical representative tells a customer that each capsule of Lohiron (MRP ₹468 for 60 capsules) costs ₹9. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmheqm79q006gjus4p3rw7ryp	cmhbuhv7e001bjus4zeld0koz	What is the recommended adult dose of Lohiron?	{"1–2 capsules twice daily after food","5 ml twice daily","1 tablet at bedtime","10 g twice daily"}	2	t	C	1–2 capsules twice daily after food	5 ml twice daily	1 tablet at bedtime	10 g twice daily	\N	MCQ_4
cmheqnszk006ijus469wgybvy	cmhbuisyj001ejus4c4v4urph	What is the primary therapeutic benefit of Eeezar?	{"Supports thyroid function","Manages recurrent allergies, sinusitis, airway disorders, urticaria, and boosts immunity","Enhances male fertility","Lowers cholesterol and triglycerides"}	1	t	B	Supports thyroid function	Manages recurrent allergies, sinusitis, airway disorders, urticaria, and boosts immunity	Enhances male fertility	Lowers cholesterol and triglycerides	\N	MCQ_4
cmheqo5ix006kjus4jmh0gw31	cmhbuisyj001ejus4c4v4urph	Nisha (Curcuma longa – Curcumin) in Eeezar acts as an anti-inflammatory and anti-histaminic agent that reduces bronchial irritation and allergic responses.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmheqp7u9006mjus40g6mz99z	cmhbuisyj001ejus4c4v4urph	Which herb in Eeezar strengthens immune function and replenishes immune cells?	{Amalaki,Guduchi,Devadaru,Yashtimadhu}	1	t	B	Amalaki	Guduchi	Devadaru	Yashtimadhu	\N	MCQ_4
cmheqqfzq006qjus42x4ajotl	cmhbuisyj001ejus4c4v4urph	A medical representative tells a customer that each tablet of Eeezar (MRP ₹206 for 30 tablets) costs ₹8. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmheqsb1v006sjus4if69qpxu	cmhbuisyj001ejus4c4v4urph	What is the recommended adult dose of Eeezar?	{"1–2 tablets twice daily, or as directed by the physician","1–2 tablets once daily at bedtime","5 ml twice daily","10 g twice daily after food"}	0	t	A	1–2 tablets twice daily, or as directed by the physician	1–2 tablets once daily at bedtime	5 ml twice daily	10 g twice daily after food	\N	MCQ_4
cmheqtz5m006ujus4zdmshhtj	cmhbulahm001hjus43sgdixbv	Which of the following best describes the triple action of Laxcef tablets?	{"Relieves constipation, reduces flatulence, and provides mild detoxification","Improves appetite, enhances liver function, and reduces acidity","Acts as an analgesic, antipyretic, and anti-inflammatory","Boosts energy, reduces fatigue, and enhances metabolism"}	0	t	A	Relieves constipation, reduces flatulence, and provides mild detoxification	Improves appetite, enhances liver function, and reduces acidity	Acts as an analgesic, antipyretic, and anti-inflammatory	Boosts energy, reduces fatigue, and enhances metabolism	\N	MCQ_4
cmhg6ml6c006wjus43gs523hq	cmhbulahm001hjus43sgdixbv	Sonamukhi (Cassia angustifolia) in Laxcef acts as a stimulant laxative promoting bowel clearance.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg6o2ej006yjus4cuxo1q8n	cmhbulahm001hjus43sgdixbv	Jayapala (Croton tiglium) is included in Laxcef primarily for its:	{"Sedative action","Vermifuge and purgative action","Antioxidant property","Antacid effect"}	1	t	B	Sedative action	Vermifuge and purgative action	Antioxidant property	Antacid effect	\N	MCQ_4
cmhg6pnyi0070jus4ijgft8oq	cmhbulahm001hjus43sgdixbv	What is the recommended dose of Laxcef for adults?	{"1–2 tablets in the morning before breakfast","1–2 tablets at bedtime with lukewarm water","2 tablets twice daily after meals","1 tablet after lunch"}	1	t	B	1–2 tablets in the morning before breakfast	1–2 tablets at bedtime with lukewarm water	2 tablets twice daily after meals	1 tablet after lunch	\N	MCQ_4
cmhg6q22c0072jus40ys45zz0	cmhbulahm001hjus43sgdixbv	The MRP of Laxcef (pack of 10×10 tablets) is ₹469, making the price per tablet ₹4.69.	{Incorrect,Correct}	1	t	B	\N	Correct	\N	\N	\N	MCQ_2
cmhg6sh4t0074jus4m04qmqke	cmhbum86d001kjus4bgbltt4i	What is the main benefit of Thyrovib?	{"Supports digestive health and detoxification","Enhances fertility in women","Relieves joint pain and muscle fatigue","Optimizes thyroid hormone balance (TSH, T3, T4) and regulates metabolism"}	1	t	B	Supports digestive health and detoxification	Enhances fertility in women	Relieves joint pain and muscle fatigue	Optimizes thyroid hormone balance (TSH, T3, T4) and regulates metabolism	\N	MCQ_4
cmhg6suhu0076jus4s7ja9hh7	cmhbum86d001kjus4bgbltt4i	Kanchanara Guggulu in Thyrovib helps regulate thyroid swelling and function.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg6u2ef0078jus46d2epzc4	cmhbum86d001kjus4bgbltt4i	Which ingredient in Thyrovib acts as an adaptogen and antioxidant supporting cognitive balance and hormonal regulation?	{Brahmi,Gandira,Kanchanara,Punarnava}	0	t	A	Brahmi	Gandira	Kanchanara	Punarnava	\N	MCQ_4
cmhg6uhhb007ajus4eevgy9fi	cmhbum86d001kjus4bgbltt4i	If a 10×10 capsule pack of Thyrovib costs ₹938, a sales rep tells a doctor that each capsule costs ₹10. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhg6uu65007cjus4ckq13amq	cmhbum86d001kjus4bgbltt4i	Recommended adult dose is 1–2 capsules twice daily after meals.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg6wg0n007ejus42aacqm20	cmhbuntgs001njus4cf4426d5	Which ingredient in Strong Joint acts as a natural anti-inflammatory that eases joint pain and slows cartilage degeneration?	{"Shallaki Extract (Boswellia serrata)","Haridra Rhizome (Curcuma longa)","Glucosamine (Chingati Satwa)","None of the above"}	0	t	A	Shallaki Extract (Boswellia serrata)	Haridra Rhizome (Curcuma longa)	Glucosamine (Chingati Satwa)	None of the above	\N	MCQ_4
cmhg6wq8g007gjus482tu4p4d	cmhbuntgs001njus4cf4426d5	Glucosamine in Strong Joint primarily supports cartilage health, lubrication, and smooth mobility.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg6z4uo007kjus4v9xarfzo	cmhbuntgs001njus4cf4426d5	What is the recommended dose of Strong Joint tablets?	{"1 tablet once daily only","1–2 tablets daily","2 tablets thrice daily","1 tablet every alternate day"}	1	t	B	1 tablet once daily only	1–2 tablets daily	2 tablets thrice daily	1 tablet every alternate day	\N	MCQ_4
cmhg70cg9007mjus40wc6ypit	cmhbuntgs001njus4cf4426d5	Price per tablet in the 60-tablet pack of Strong Joint is approximately:	{₹9.5,₹10,₹8.9,₹8}	2	t	C	₹9.5	₹10	₹8.9	₹8	\N	MCQ_4
cmhg72u52007ojus4atnqirkq	cmhbusxqp001qjus4vwagef6p	Which ingredient in Kalcium N is a natural source of calcium that strengthens bones and aids fracture healing?	{"Asthishrunkala Extract",Shigru,"Moringa leaf powder","Mukta Shukti Bhasma"}	3	t	D	Asthishrunkala Extract	Shigru	Moringa leaf powder	Mukta Shukti Bhasma	\N	MCQ_4
cmhg7368u007qjus453ysc3i7	cmhbusxqp001qjus4vwagef6p	Asthishrunkala in Kalcium N is osteogenic and supports bone mineralization.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg747tb007sjus4d8938qs2	cmhbusxqp001qjus4vwagef6p	Kalcium N is primarily indicated in:	{"Osteoporosis and calcium deficiency","Digestive disorders","Liver disorders","Respiratory weakness"}	0	t	A	Osteoporosis and calcium deficiency	Digestive disorders	Liver disorders	Respiratory weakness	\N	MCQ_4
cmhg765yf007ujus472atjsns	cmhbusxqp001qjus4vwagef6p	The recommended dose of Kalcium N is:	{"1 tablet once daily","2 tablets thrice daily","1–2 tablets twice daily","1 tablet every alternate day"}	2	t	C	1 tablet once daily	2 tablets thrice daily	1–2 tablets twice daily	1 tablet every alternate day	\N	MCQ_4
cmhg76vdb007wjus4qggg8xc4	cmhbusxqp001qjus4vwagef6p	The price per tablet of Kalcium N is approximately is INR 10	{Incorrect,Correct}	1	t	B	\N	Correct	\N	\N	\N	MCQ_2
cmhg78upw007yjus4kzpq00me	cmhbutxe1001tjus4z6fimo8s	What is the primary therapeutic benefit of Panchavalkala Kwatha?	{"Supports thyroid health","Acts as a natural astringent, wound-healing, anti-inflammatory, and antimicrobial remedy","Enhances male fertility and libido","Reduces blood glucose and supports pancreatic health"}	1	t	B	Supports thyroid health	Acts as a natural astringent, wound-healing, anti-inflammatory, and antimicrobial remedy	Enhances male fertility and libido	Reduces blood glucose and supports pancreatic health	\N	MCQ_4
cmhg79bz10080jus4le0d5jdn	cmhbutxe1001tjus4z6fimo8s	Udumbara (Ficus racemosa) in Panchavalkala Kwatha has anti-inflammatory and antimicrobial properties and supports skin and mucosal health.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg7ajqf0082jus4feuijg14	cmhbutxe1001tjus4z6fimo8s	Which Ficus species in Panchavalkala Kwatha is antiseptic and supports gynecological and anorectal health?	{"Parisha (Ficus benjamina / Thespesia populnea)","Ashwatha (Ficus religiosa)","Plaksha (Ficus lacor / Ficus infectoria)","Vata (Ficus benghalensis)"}	0	t	A	Parisha (Ficus benjamina / Thespesia populnea)	Ashwatha (Ficus religiosa)	Plaksha (Ficus lacor / Ficus infectoria)	Vata (Ficus benghalensis)	\N	MCQ_4
cmhg7b3rz0084jus4kam6787j	cmhbutxe1001tjus4z6fimo8s	If a 100 ml pack of Panchavalkala Kwatha costs ₹103.12, a sales rep tells a customer that each ml costs ₹1.05. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhg7ces30086jus4hn7o6fyb	cmhbutxe1001tjus4z6fimo8s	Panchavalkala kwatha is used for external purposes?	{Incorrect,Correct}	1	t	B	\N	Correct	\N	\N	\N	MCQ_2
cmhg7eg6x0088jus448g8se10	cmhbuxl97001zjus4dwcin9hk	What is the primary therapeutic benefit of Swarna Sekhara Rasa?	{"Supports thyroid hormone balance","Enhances digestive power, relieves indigestion, heartburn, acidity, and balances Pitta","Manages recurrent allergies","Improves fertility and reproductive health"}	1	t	B	Supports thyroid hormone balance	Enhances digestive power, relieves indigestion, heartburn, acidity, and balances Pitta	Manages recurrent allergies	Improves fertility and reproductive health	\N	MCQ_4
cmhg7f3sj008ajus49cdbpbr8	cmhbuxl97001zjus4dwcin9hk	Kamaladhuta Rasa in Swarna Sekhara Rasa regulates stomach acid, relieves hyperacidity, and soothes gastric irritation.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg7g7wz008cjus4iazubgzr	cmhbuxl97001zjus4dwcin9hk	Which component in Swarna Sekhara Rasa acts as a natural antacid and reduces burning sensation?	{"Avipathikara Churna","Narikel Lavana","Swarnamakshika Bhasma","Swarnasutasekhara Rasa"}	1	t	B	Avipathikara Churna	Narikel Lavana	Swarnamakshika Bhasma	Swarnasutasekhara Rasa	\N	MCQ_4
cmhg7gr88008ejus4z187jalp	cmhbuxl97001zjus4dwcin9hk	A medical representative claims that each tablet of Swarna Sekhara Rasa (MRP ₹800 for 30 tablets) costs ₹30. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhg7hsf4008gjus40e32hz9f	cmhbuxl97001zjus4dwcin9hk	What is the recommended adult dose of Swarna Sekhara Rasa?	{"1–2 tablets twice daily, or as directed by the physician","5 ml twice daily","1 tablet at bedtime only","10 g twice daily"}	0	t	A	1–2 tablets twice daily, or as directed by the physician	5 ml twice daily	1 tablet at bedtime only	10 g twice daily	\N	MCQ_4
cmhg7j8a3008ijus4xqze14ox	cmhbv0zd80022jus4mggj6qsr	What is the primary benefit of Shishu Kalyana Rasa?	{"Supports child growth, immunity, cognitive development, and protects against recurrent infections","Improves digestion in adults","Enhances fertility in females","Relieves constipation and bloating"}	0	t	A	Supports child growth, immunity, cognitive development, and protects against recurrent infections	Improves digestion in adults	Enhances fertility in females	Relieves constipation and bloating	\N	MCQ_4
cmhg7jgx5008kjus4z10slliw	cmhbv0zd80022jus4mggj6qsr	Pravala Bhasma (Coral calc.) in this formulation primarily strengthens bones and supports calcium metabolism.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg7kfqe008mjus4ojkzj8k4	cmhbv0zd80022jus4mggj6qsr	Which ingredient in Shishu Kalyana Rasa is used to enhance memory, speech, and cognitive function?	{"Shunti (Zingiber officinale)","Vacha (Acorus calamus)","Yashtimadhu (Glycyrrhiza glabra)","Haritaki (Terminalia chebula)"}	1	t	B	Shunti (Zingiber officinale)	Vacha (Acorus calamus)	Yashtimadhu (Glycyrrhiza glabra)	Haritaki (Terminalia chebula)	\N	MCQ_4
cmhgd4qo1008ojus4mik77xaa	cmhbv0zd80022jus4mggj6qsr	A colleague claims that each tablet of Shishu Kalyana Rasa (MRP ₹1900 for 30 tablets) costs ₹70.	{TRUE,FALSE}	1	t	FALSE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgd6949008qjus43dwa28de	cmhbv0zd80022jus4mggj6qsr	What is the recommended dose for children?	{"1 tablet twice daily or as directed by the physician","5 ml twice daily","10 g twice daily","1 tablet once daily only"}	3	t	FALSE	1 tablet twice daily or as directed by the physician	5 ml twice daily	10 g twice daily	1 tablet once daily only	\N	MCQ_4
cmhge2189008sjus4u5adyaa1	cmhbv39mq0025jus4r9lp9fcp	What is the main purpose of Tatvam HB?	{"Supports female fertility","Enhances bone strength and calcium absorption","Improves digestion and metabolism","Supports healthy skin by managing dermatitis, allergies, acne, and rashes"}	3	t	D	Supports female fertility	Enhances bone strength and calcium absorption	Improves digestion and metabolism	Supports healthy skin by managing dermatitis, allergies, acne, and rashes	\N	MCQ_4
cmhge2afz008ujus4johtq6sy	cmhbv39mq0025jus4r9lp9fcp	Manjishta Ext. (Rubia cordifolia) in Tatvam HB helps improve skin complexion and detoxifies blood.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhge3gbl008wjus4vsvn5rxn	cmhbv39mq0025jus4r9lp9fcp	Which ingredient in Tatvam HB is known for its anti-bacterial and anti-allergic properties, useful in acne and dermatitis?	{"Nimba Ext. (Azadirachta indica)","Chakramarda Ext. (Cassia tora)","Haridra Ext. (Curcuma longa)","Khadira Ext. (Acacia catechu)"}	3	t	TRUE	Nimba Ext. (Azadirachta indica)	Chakramarda Ext. (Cassia tora)	Haridra Ext. (Curcuma longa)	Khadira Ext. (Acacia catechu)	\N	MCQ_4
cmhge420b008yjus4phgop97k	cmhbv39mq0025jus4r9lp9fcp	A colleague says the price per tablet of Tatvam HB (MRP ₹650 for 100 tablets) is ₹7. Is this correct?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhge558e0090jus4do3jx0pw	cmhbv39mq0025jus4r9lp9fcp	What is the recommended dose of Tatvam HB?	{"5 ml twice daily","1–2 tablets twice daily, or as directed by the physician","10 g twice daily","1 tablet once daily only"}	1	t	B	5 ml twice daily	1–2 tablets twice daily, or as directed by the physician	10 g twice daily	1 tablet once daily only	\N	MCQ_4
cmhge7ixg0092jus4iaw32wlb	cmhbv4tia0028jus457bdiyaz	What is the primary benefit of Laxloma?	{"Smooth bowel regulation, relieves constipation and bloating","Supports skin health","Enhances memory and cognition","Improves sleep quality"}	0	t	A	Smooth bowel regulation, relieves constipation and bloating	Supports skin health	Enhances memory and cognition	Improves sleep quality	\N	MCQ_4
cmhge7uge0094jus4idfccmvl	cmhbv4tia0028jus457bdiyaz	Bala Haritaki Churna in Laxloma acts as a mild laxative and supports gut cleansing.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhge933k0096jus4m7qec404	cmhbv4tia0028jus457bdiyaz	Which ingredient in Laxloma is a natural purgative that clears the bowel?	{"Saindhava Lavana","Mishreya Churna","Sonamukhi Churna","Shunti Churna"}	2	t	C	Saindhava Lavana	Mishreya Churna	Sonamukhi Churna	Shunti Churna	\N	MCQ_4
cmhge9l950098jus42uwdd2cb	cmhbv4tia0028jus457bdiyaz	A medical rep mistakenly says Laxloma’s price per tablet is ₹8.50 (MRP ₹700 for 100 tablets). Is this correct?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhgeaqqd009ajus48x4m6a43	cmhbv4tia0028jus457bdiyaz	What is the recommended dose of Laxloma?	{"1–2 tablets once daily after food, or as directed by the physician","5 ml twice daily","1 tablet at bedtime only","2–3 tablets thrice daily"}	2	t	C	1–2 tablets once daily after food, or as directed by the physician	5 ml twice daily	1 tablet at bedtime only	2–3 tablets thrice daily	\N	MCQ_4
cmhgegi3a009cjus4sfqzvkh4	cmhbv73rp002bjus4b7e84qnc	What is the main purpose of Vitabin-M?	{"Improves sleep quality","Supports energy, bone health, and immunity","Reduces skin allergies","Relieves constipation"}	1	t	B	Improves sleep quality	Supports energy, bone health, and immunity	Reduces skin allergies	Relieves constipation	\N	MCQ_4
cmhgegqs4009ejus4tt0vmr27	cmhbv73rp002bjus4b7e84qnc	Vitabin-M contains both Moringa Extract and Moringa Powder to enhance immunity and provide antioxidants.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgehxlo009gjus4ynd5mxj9	cmhbv73rp002bjus4b7e84qnc	Which vitamin in Vitabin-M helps in calcium absorption and strengthens bones?	{"Vitamin B12","Vitamin D3 ","Vitamin C","Vitamin E"}	1	t	B	Vitamin B12	Vitamin D3 	Vitamin C	Vitamin E	\N	MCQ_4
cmhgej5yu009ijus41zqcm5bd	cmhbv73rp002bjus4b7e84qnc	The MRP of Vitabin-M is ₹321 for 30 tablets. What is the approximate price per tablet?	{₹12.00,₹10.70,₹15.00,₹9.50}	1	t	B	₹12.00	₹10.70	₹15.00	₹9.50	\N	MCQ_4
cmhgekrfb009kjus42h3vmg8l	cmhbv73rp002bjus4b7e84qnc	A patient is taking Vitabin-M daily. What is the correct guidance for long-term use?	{"Take only once a month","Use only during illness","Take 3 tablets daily without monitoring","Safe for daily use, monitor B12 & D3 levels periodically"}	3	t	D	Take only once a month	Use only during illness	Take 3 tablets daily without monitoring	Safe for daily use, monitor B12 & D3 levels periodically	\N	MCQ_4
cmhgema54009mjus4nm1titn0	cmhbv8ccs002ejus4q3qdhdcd	Which ingredient in Pilafar acts as a natural laxative helpful in constipation associated with piles?	{Dugdhika,"Sonamukhi (Senna)",Ativisha,"Sphatika Bhasma"}	1	t	B	Dugdhika	Sonamukhi (Senna)	Ativisha	Sphatika Bhasma	\N	MCQ_4
cmhgemrbt009ojus4dzvbfr9g	cmhbv8ccs002ejus4q3qdhdcd	Sphatika Bhasma in Pilafar helps shrink pile mass and stop bleeding through its astringent action.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgenwrz009qjus412r9p0m1	cmhbv8ccs002ejus4q3qdhdcd	Pilafar is indicated for all of the following except:	{"Internal and external hemorrhoids","Constipation associated with piles","Post-hemorrhoid surgery support","Diabetes management"}	3	t	TRUE	Internal and external hemorrhoids	Constipation associated with piles	Post-hemorrhoid surgery support	Diabetes management	\N	MCQ_4
cmhgepiw5009sjus42a2fohh8	cmhbv8ccs002ejus4q3qdhdcd	The recommended dose of Pilafar is:	{"1–2 tablets once daily before meals","2 tablets thrice daily after meals","1–2 tablets twice daily after meals","1 tablet at bedtime only"}	2	t	C	1–2 tablets once daily before meals	2 tablets thrice daily after meals	1–2 tablets twice daily after meals	1 tablet at bedtime only	\N	MCQ_4
cmhgeqe6b009ujus4dt03uyvd	cmhbv8ccs002ejus4q3qdhdcd	The approximate price per tablet of Pilafar is:	{₹15.00,₹15.60,₹16.00,₹14.50}	1	t	B	₹15.00	₹15.60	₹16.00	₹14.50	\N	MCQ_4
cmhgespep009wjus41y1f9ttx	cmhbv9hh9002hjus4lgw71w1u	What is the main benefit of Lipidof Combo?	{"Supports thyroid function","Manages high lipid levels, lowers LDL & triglycerides, and supports heart health","Improves digestion and bowel movement only","Enhances male fertility and stamina"}	1	t	B	Supports thyroid function	Manages high lipid levels, lowers LDL & triglycerides, and supports heart health	Improves digestion and bowel movement only	Enhances male fertility and stamina	\N	MCQ_4
cmhget3sd009yjus436x2upqi	cmhbv9hh9002hjus4lgw71w1u	Shuddha Guggulu in Lipidof Combo acts as a classical hypolipidemic agent, reducing LDL, triglycerides, and plaque formation.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgeu0yg00a0jus4964kr67s	cmhbv9hh9002hjus4lgw71w1u	Which ingredient in Lipidof Combo is rich in antioxidants and protects heart health?	{Amalaki,Daruharidra,Haridra,Chitraka}	0	t	A	Amalaki	Daruharidra	Haridra	Chitraka	\N	MCQ_4
cmhgeue4z00a2jus4viehi3yz	cmhbv9hh9002hjus4lgw71w1u	If a pack of Lipidof Combo (Lipidof 30 tabs + Navaka Guggulu 30 tabs) costs ₹328, a sales rep tells a customer that each tablet costs ₹6. Is this correct or incorrect?	{Incorrect,Correct}	0	t	A	\N	Correct	\N	\N	\N	MCQ_2
cmhgevxd900a4jus4ds51rhls	cmhbv9hh9002hjus4lgw71w1u	Recommended adult dose of Lipidof Combo is:	{"1 tablet each twice daily after food","5 ml twice daily","1 tablet at bedtime","10 g twice daily"}	0	t	A	1 tablet each twice daily after food	5 ml twice daily	1 tablet at bedtime	10 g twice daily	\N	MCQ_4
cmhgf06aa00a6jus4pomxj4qy	cmhbvq3ur002njus4cvyv4we2	What is the primary benefit of Vajeevan Lehya?	{"Enhances digestion and immunity","Improves male sexual strength, stamina, fertility, and libido naturally","Relieves joint pain and muscle fatigue","Supports kidney and urinary health"}	1	t	B	Enhances digestion and immunity	Improves male sexual strength, stamina, fertility, and libido naturally	Relieves joint pain and muscle fatigue	Supports kidney and urinary health	\N	MCQ_4
cmhgf0iaa00a8jus4u1ppl38f	cmhbvq3ur002njus4cvyv4we2	Kapikacchu (Mucuna pruriens) in Vajeevan Lehya is rich in L-Dopa and helps improve sperm count and motility.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgf1dxb00aajus4nv1b0d8x	cmhbvq3ur002njus4cvyv4we2	Which ingredient in Vajeevan Lehya acts as an adaptogen, reduces stress, and enhances sexual vigor?	{Rathnapurusha,Gokshura,Ashwagandha,Kapikacchu}	2	t	C	Rathnapurusha	Gokshura	Ashwagandha	Kapikacchu	\N	MCQ_4
cmhgf2ck600acjus485atagbp	cmhbvq3ur002njus4cvyv4we2	If a 350 g pack of Vajeevan Lehya costs ₹563, approximately how much does 10 g cost?	{₹15.9,₹16,₹16.1,₹16.2}	1	t	B	₹15.9	₹16	₹16.1	₹16.2	\N	MCQ_4
cmhgf2zrz00aejus4mds438ie	cmhbvq3ur002njus4cvyv4we2	Recommended adult dose is 5–10 g twice daily before food with warm milk.	{Incorrect,Correct}	1	t	B	\N	Correct	\N	\N	\N	MCQ_2
cmhgf4vc800agjus4e2ohbujq	cmhbvwu7p002qjus4wd964v8j	Rasa Sindura in Immunoj™ primarily acts as a rejuvenator and helps enhance absorption.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgf5qmn00aijus4zf1fj8v0	cmhbvwu7p002qjus4wd964v8j	Which of the following ingredients in Immunoj™ is known as a Rasayana herb that enhances immunity and detoxifies?	{Tulasi,"Amritha (Guduchi)","Haridra (Turmeric)",Ashwagandha}	1	t	B	Tulasi	Amritha (Guduchi)	Haridra (Turmeric)	Ashwagandha	\N	MCQ_4
cmhgf6qr400akjus4a354bukj	cmhbvwu7p002qjus4wd964v8j	Which patient group should avoid taking Immunoj™?	{"Children with recurrent cough and cold","Pregnant and lactating women","Elderly with low immunity","Adults with frequent skin infections"}	1	t	B	Children with recurrent cough and cold	Pregnant and lactating women	Elderly with low immunity	Adults with frequent skin infections	\N	MCQ_4
cmhgf7rio00amjus4gwgh5f1c	cmhbvwu7p002qjus4wd964v8j	The recommended dose of Immunoj™ is:	{"1 tablet once daily","2 tablets three times daily","1–2 tablets twice daily","1 tablet after meals only"}	2	t	C	1 tablet once daily	2 tablets three times daily	1–2 tablets twice daily	1 tablet after meals only	\N	MCQ_4
cmhhqpd9c00aqjus4dher86bu	cmhbuvg3g001wjus4d8oed9ls	Which of the following is not an indication for using Chiramol Tablet?	{"Recurrent fever","Immunity enhancement","Liver health support","Joint lubrication"}	3	t	D	Recurrent fever	Immunity enhancement	Liver health support	Joint lubrication	\N	MCQ_4
cmhhqr36900asjus4he7no7df	cmhbuvg3g001wjus4d8oed9ls	Chiramol Tablet is indicated in managing intermittent and recurrent fevers.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhhqx9be00aujus46fupain3	cmhbuvg3g001wjus4d8oed9ls	Chiramol Tablet can be recommended for which of the following conditions?	{"Infection and fever","Diabetic neuropathy","Joint stiffness",Insomnia}	0	t	A	Infection and fever	Diabetic neuropathy	Joint stiffness	Insomnia	\N	MCQ_4
cmhhqyz6500awjus4dopt6fwr	cmhbuvg3g001wjus4d8oed9ls	Can Chiramol Tablet be used to support liver health and detoxification?	{Yes,No}	0	t	A	\N	No	\N	\N	\N	MCQ_2
cmhhr0b8b00ayjus44lzexg7b	cmhbuvg3g001wjus4d8oed9ls	Chiramol Tablet helps combat infections due to which type of action?	{"Antipyretic and immunomodulatory","Sedative and cooling","Laxative and diuretic","Antacid and digestive"}	0	t	A	Antipyretic and immunomodulatory	Sedative and cooling	Laxative and diuretic	Antacid and digestive	\N	MCQ_4
cmhhsmzwh00b3jus4css91ble	cmhhs4fwv00b1jus4xkmmk4qg	What is the main benefit of Madhuhara Churna?	{"Supports thyroid function","Helps manage Type 2 Diabetes Mellitus, balances blood glucose, and reduces complications","Enhances male fertility and sexual performance","Relieves constipation and bloating"}	1	t	B	Supports thyroid function	Helps manage Type 2 Diabetes Mellitus, balances blood glucose, and reduces complications	Enhances male fertility and sexual performance	Relieves constipation and bloating	\N	MCQ_4
cmhhsnb3300b5jus40i1lkt6e	cmhhs4fwv00b1jus4xkmmk4qg	Jambu (Syzygium cumini) in Madhuhara Churna regulates blood sugar and supports pancreatic health.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhhsovuv00b7jus4kyewf0fi	cmhhs4fwv00b1jus4xkmmk4qg	Which herb in Madhuhara Churna is rich in soluble fiber and supports glucose homeostasis?	{Guduchi,"Methika (Fenugreek)",Saptaparna,"Karavellaka (Bitter gourd)"}	1	t	B	Guduchi	Methika (Fenugreek)	Saptaparna	Karavellaka (Bitter gourd)	\N	MCQ_4
cmhhspthz00b9jus4ndgn90lx	cmhhs4fwv00b1jus4xkmmk4qg	A chemist claims that each gram of Madhuhara Churna (MRP ₹309 for 200 g) costs ₹2. Is this correct or incorrect?	{Correct,Incorrect}	1	t	B	\N	Incorrect	\N	\N	\N	MCQ_2
cmhhsrpty00bbjus4iozudxm9	cmhhs4fwv00b1jus4xkmmk4qg	Which of the following is the correct recommended adult dose of Madhuhara Churna?	{"5 g with warm water before food","1 tablet at bedtime with lukewarm water","5–10 ml twice daily after meals","1–2 capsules twice daily before food"}	0	t	A	5 g with warm water before food	1 tablet at bedtime with lukewarm water	5–10 ml twice daily after meals	1–2 capsules twice daily before food	\N	MCQ_4
cmhhumc8400bjjus4qhathyb6	cmhhukx8g00bhjus4ams40h2l	What is the primary therapeutic purpose of Fertivibes?	{"Supports female fertility, ovulatory health, and uterine strength without hormonal side effects","Improves digestion and appetite","Alkalizes urinary system and reduces kidney stones","Relieves menstrual cramps only"}	0	t	A	Supports female fertility, ovulatory health, and uterine strength without hormonal side effects	Improves digestion and appetite	Alkalizes urinary system and reduces kidney stones	Relieves menstrual cramps only	\N	MCQ_4
cmhhummic00bljus49n9h041h	cmhhukx8g00bhjus4ams40h2l	Ashoka (Saraca indica) in Fertivibes helps regulate the menstrual cycle and tones the uterus.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhgf83dv00aojus4q8g0lmrn	cmhbvwu7p002qjus4wd964v8j	Each pack of Immunoj™ contains 30 tablets priced at ₹422, making the cost per tablet ₹14.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhhunrey00bnjus4ee6nuow8	cmhhukx8g00bhjus4ams40h2l	Which ingredient is traditionally used to promote ovulation and support conception in Fertivibes?	{Putranjeevaka,"Shivalingi Beeja","Garbhadharak Yoga",Lodhra}	1	t	B	Putranjeevaka	Shivalingi Beeja	Garbhadharak Yoga	Lodhra	\N	MCQ_4
cmhhuosyv00bpjus4twjse9kw	cmhhukx8g00bhjus4ams40h2l	A patient asks the price per tablet of Fertivibes (MRP ₹750 for 60 tablets). Which of the following is correct?	{₹10,₹12.50,₹15,₹20}	1	t	B	₹10	₹12.50	₹15	₹20	\N	MCQ_4
cmhhup7xc00brjus4jwr6h5lb	cmhhukx8g00bhjus4ams40h2l	Recommended dose is 1–2 tablets twice daily after meals with lukewarm water.	{Yes,No}	0	t	A	\N	No	\N	\N	\N	MCQ_2
cmhk8kflj0007juhz95mgm348	cmhht5ev300bejus4kgumi0vi	What is the primary composition of Shilajit?	{"Vitamins and amino acids","Humic substances and minerals","Proteins and carbohydrates","Essential oils and alkaloids"}	1	t	B	Vitamins and amino acids	Humic substances and minerals	Proteins and carbohydrates	Essential oils and alkaloids	\N	MCQ_4
cmhk8m8z40009juhzw3pvakif	cmhht5ev300bejus4kgumi0vi	Fulvic acid, a key component of Shilajit, mainly helps in:	{"Increasing blood sugar levels","Improving sleep quality","Enhancing nutrient absorption and antioxidant activity","Promoting hair growth"}	2	t	C	Increasing blood sugar levels	Improving sleep quality	Enhancing nutrient absorption and antioxidant activity	Promoting hair growth	\N	MCQ_4
cmhk8q21l000bjuhzb6fctr0m	cmhht5ev300bejus4kgumi0vi	The standard dosage of Shilajit for daily use is:	{"50–100 mg","100–200 mg","300–500 mg","1 g or more"}	2	t	C	50–100 mg	100–200 mg	300–500 mg	1 g or more	\N	MCQ_4
cmhk8qjka000djuhzs5rdzxpm	cmhht5ev300bejus4kgumi0vi	Shilajit is recommended for use in chronic fatigue and stress conditions.	{TRUE,FALSE}	0	t	TRUE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhk8r838000fjuhzq0tk2nw8	cmhht5ev300bejus4kgumi0vi	Shilajit is derived from the resin of tropical trees growing in low-altitude regions.	{TRUE,FALSE}	1	t	FALSE	\N	\N	\N	\N	\N	TRUE_FALSE
cmhg6xt4e007ijus44ynpth8g	cmhbuntgs001njus4cf4426d5	Strong Joint tablets are indicated for all of the following except:	{Diabetes,"Rheumatoid arthritis","Frozen shoulder",Osteoarthritis}	0	t	A	Diabetes	Rheumatoid arthritis	Frozen shoulder	Osteoarthritis	\N	MCQ_4
\.


--
-- Data for Name: QuestionImport; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."QuestionImport" (id, "uploadedById", "fileName", "uploadDate", "totalQuestions", "successfulImports", "failedImports", "errorLog") FROM stdin;
\.


--
-- Data for Name: Quiz; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."Quiz" (id, "moduleId", "passScore", "timeLimitSeconds") FROM stdin;
cmh98vb7m000ejus4ug87986n	cmh98vb7g000cjus4b38uu9r1	70	300
cmh98wlaw000hjus48ipygiip	cmh98wlat000fjus4fn1buajs	70	300
cmh98zs2c000kjus40tgi0zgj	cmh98zs29000ijus4vc4ns8em	70	300
cmh991vo4000njus4ukk2o5zn	cmh991vo2000ljus4wuczvof9	70	300
cmh99dn5b000qjus4avmfpfk2	cmh99dn56000ojus4bfxenktn	70	300
cmhbt2mox000tjus44peic7ao	cmhbt2moh000rjus4zvnsxk9f	70	300
cmhbte1b3000wjus4a2l81p46	cmhbte1av000ujus4rmmrluk4	70	300
cmhbtfjni000zjus4znysa68n	cmhbtfjne000xjus4323d3qnv	70	300
cmhbtm5vm0012jus4dgwn4hr8	cmhbtm5vi0010jus4nkytbce9	70	300
cmhbucn5l0015jus4srzatt54	cmhbucn5h0013jus4ds8swhpv	70	300
cmhbuekjz0018jus42kovttsw	cmhbuekjx0016jus4kl22t0xl	70	300
cmhbuhv7e001bjus4zeld0koz	cmhbuhv7b0019jus4rbdenk57	70	300
cmhbuisyj001ejus4c4v4urph	cmhbuisyg001cjus4b9ctt29g	70	300
cmhbulahm001hjus43sgdixbv	cmhbulahk001fjus4rpttdlhu	70	300
cmhbum86d001kjus4bgbltt4i	cmhbum86b001ijus4mp4faa0g	70	300
cmhbuntgs001njus4cf4426d5	cmhbuntgq001ljus478vhzwp1	70	300
cmhbusxqp001qjus4vwagef6p	cmhbusxqm001ojus4ou9j4r2r	70	300
cmhbutxe1001tjus4z6fimo8s	cmhbutxdz001rjus4i2jddkpq	70	300
cmhbuvg3g001wjus4d8oed9ls	cmhbuvg3d001ujus461a5o7yw	70	300
cmhbuxl97001zjus4dwcin9hk	cmhbuxl95001xjus40y3mn0u4	70	300
cmhbv0zd80022jus4mggj6qsr	cmhbv0zd50020jus41qmurywm	70	300
cmhbv39mq0025jus4r9lp9fcp	cmhbv39mm0023jus4ejws4116	70	300
cmhbv4tia0028jus457bdiyaz	cmhbv4ti90026jus4yf5whuyz	70	300
cmhbv73rp002bjus4b7e84qnc	cmhbv73rn0029jus4meo8nn2u	70	300
cmhbv8ccs002ejus4q3qdhdcd	cmhbv8ccn002cjus4ystimx3h	70	300
cmhbv9hh9002hjus4lgw71w1u	cmhbv9hh7002fjus4o9ejb0np	70	300
cmhbvaovs002kjus4tjj33ova	cmhbvaovq002ijus4cw8w6mqf	70	300
cmhbvq3ur002njus4cvyv4we2	cmhbvq3uo002ljus4me2p1en7	70	300
cmhbvwu7p002qjus4wd964v8j	cmhbvwu7m002ojus42y0pd3qh	70	300
cmhhs4fwv00b1jus4xkmmk4qg	cmhhs4fwp00azjus4m7vppmkt	70	300
cmhhukx8g00bhjus4ams40h2l	cmhhukx8e00bfjus4pscyib31	70	300
cmhht5ev300bejus4kgumi0vi	cmhht5ev000bcjus4mc5ay8ve	70	300
cmh98n3xn000bjus4t2641bic	cmh98n3xk0009jus4ui0frx5m	70	300
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public."User" (id, email, name, role, "passwordHash", "emailVerifiedAt", "mfaSecret", "disabledAt", "lockedUntil", "lastLoginAt", "createdAt", "updatedAt") FROM stdin;
cmhj3gkgo00bxjus4teiqpmwk	producthead@ayurcentral.com	Dr. Manoj 	EMPLOYEE	$2b$10$PvW.xV0hF7ZemU6nBki2.eLE70bfrdceEqcqnO2cQ9Ci6MC4fvEEW	2025-11-03 12:07:03.656	\N	\N	\N	2025-11-04 06:07:53.69	2025-11-03 12:06:19.033	2025-11-04 06:07:53.692
cmhncl9ed001ojuhzllnopeao	mkarthick467@gmail.com	mkarthick467@gmail.com	EMPLOYEE	$2b$10$EzmHxZBtwW8V618NdjG5WOmW1gR4g8gmw8q6XXA.KmvfJQnMW.3qu	2025-11-06 11:37:20.654	\N	\N	\N	2025-11-06 11:37:41.554	2025-11-06 11:32:59.221	2025-11-06 11:37:41.555
cmhncj5d2001mjuhz3ndb98di	chaudharikiran645@gmail.com	Kiran Gurunath Chaudhari 	EMPLOYEE	$2b$10$SR1Vargzn/l6UhmTViBlueffLmBiDcoN8WsY84wOrmzkGpEyni4k2	2025-11-07 10:02:32.804	\N	\N	\N	2025-11-07 10:02:48.136	2025-11-06 11:31:20.678	2025-11-07 10:02:48.144
cmgt7o0gq0000jua6wsrukcnr	satish87@live.com	Satish	EMPLOYEE	$2b$10$lP9vxVe7b2ptifyvMtjJS.TaKTPRTnGAUF0N7wycaad6gb3JjCgee	2025-10-16 09:27:59.884	\N	\N	\N	2025-11-08 06:46:57.763	2025-10-16 09:22:04.25	2025-11-08 06:46:57.769
cmhljnqlx000ujuhz3eqr5nq9	gram150@gmail.com	gangaram	EMPLOYEE	$2b$10$0fXFkYtioXjWwT3vykaeKeZsdV2QMSS4hDHrz88VEoYWtglpdiYGy	2025-11-05 05:19:59.527	\N	\N	\N	2025-11-05 05:20:33.722	2025-11-05 05:15:19.797	2025-11-05 05:20:33.723
cmgqg7ih10000jusa54l9kemh	itsupport@ayurcentral.com	IT	ADMIN	$2b$10$5isw3LhSLeLKFcgoDlQiwug65BzBzmTQI7QPT/TGS7zD9vIxFC7.a	2025-10-14 10:57:52.451	\N	\N	\N	2025-10-15 07:03:39.157	2025-10-14 10:57:52.453	2025-10-16 09:21:40.497
cmhljp2x3000vjuhzfvgqes6u	shashikiran38s@gmail.com	Shashikiran. S	EMPLOYEE	$2b$10$E0FCngTHDKHJX3fYKRnuLuRRmcsyRiacXzIb/76ZzIcgJW5vm8VgW	2025-11-05 06:01:56.946	\N	\N	\N	2025-11-05 06:02:35.196	2025-11-05 05:16:22.408	2025-11-05 06:02:35.198
cmhnclsdw001pjuhzlmogdf2n	ramesh1536769@gmail.com	Ramesh	EMPLOYEE	$2b$10$nykY08gZR1zcduI1ADw6Eu5BsYZL5A.al9zOQXPKKCPZFLd34Zp12	2025-11-06 11:43:08.658	\N	\N	\N	2025-11-06 11:43:42.644	2025-11-06 11:33:23.828	2025-11-06 11:45:05.943
cmhllnlfb000wjuhzwjk0pa6t	avinashkadale0@gmail.com	Avinash kadale	EMPLOYEE	$2b$10$8rIn3BqF7zbYJH6KoDu/ROYtJqGKZC03gizYbGBvJSK/tAmsWnyHK	2025-11-05 06:17:35.167	\N	\N	\N	2025-11-05 06:18:59.717	2025-11-05 06:11:12.312	2025-11-05 06:18:59.718
cmhnca88k001gjuhzzsy6094t	senthil1234.sp@gmail.com	Senthilprabhu	EMPLOYEE	$2b$10$LY7mZj3yo8K4UYr4Bea2Qu8ojwHTsZlRHgxC1.NDPwoDD0GZlPSJS	2025-11-06 12:06:58.76	\N	\N	\N	\N	2025-11-06 11:24:24.501	2025-11-06 12:06:58.761
cmhj2sveo00bsjus4zm3lbtm5	drusha.saral@gmail.com	drusha.saral@gmail.com	EMPLOYEE	$2b$10$Q3Zo26/.n/9v/1PwJCfz1e/DUKiYd0H.0THuB2tpxvawomr5dVOnO	2025-11-03 11:48:25.619	\N	\N	\N	2025-11-06 10:48:32.143	2025-11-03 11:47:53.47	2025-11-06 10:48:32.144
cmhncbc21001hjuhzgtgyz0ho	nikhilmane221@gmail.com	Nikhil jagannath mane 	EMPLOYEE	$2b$10$cdIubZiucgYC0Yaq/GuRueJ671qgUZevthMYX1YxcMQ.pg2i5Vyx.	\N	\N	\N	\N	\N	2025-11-06 11:25:16.105	2025-11-06 11:25:16.105
cmhncc3sp001ijuhzdq3rstwn	ballalshrirang@gmail.com	Shrirang Ballal	EMPLOYEE	$2b$10$fBk7FTlmB19OF61KSlMakuBefcoQAQp3dQvbiNEVDT4kVmvg3hZQO	\N	\N	\N	\N	\N	2025-11-06 11:25:52.058	2025-11-06 11:25:52.058
cmhncg8t7001jjuhzenbzyb1u	singhprashant560@ymail.com	Prashant Rajesh Singh	EMPLOYEE	$2b$10$7brWJnvfyUsAOeOuw.F53e.kTSDhD08juwQfI89p5qLB8MMU4/5z6	\N	\N	\N	\N	\N	2025-11-06 11:29:05.179	2025-11-06 11:29:05.179
cmhnch3hh001kjuhzgc4hyal5	msrivastava0712@gmail.com	MANISH SRIVASTAVA	EMPLOYEE	$2b$10$eZLRTCqCVEOTZUvSTpeEkuzWTISQDCsZBsaZxj0tn1Xg10h/cxR8.	\N	\N	\N	\N	\N	2025-11-06 11:29:44.933	2025-11-06 11:29:44.933
cmhnco0hd001sjuhzdnktgigp	ravi161219@gmail.com	Ravi bk 	EMPLOYEE	$2b$10$erKHZ.TliqtKa5TfJaWCnOgGJNYeiA9y9gJIIFbjKz1vDqwPzSZdO	2025-11-06 12:20:32.756	\N	\N	\N	2025-11-06 12:20:54.585	2025-11-06 11:35:07.634	2025-11-06 12:20:54.586
cmhnchss0001ljuhzhmhjlzmv	ms3232635@gmail.com	ms3232635@gmail.com	EMPLOYEE	$2b$10$U2UcJg1b3H2aKPtxf/VBtex82K9xFuZu0P9F6bObMtUanp1OdQc6a	2025-11-06 12:29:48.723	\N	\N	\N	2025-11-06 12:30:08.441	2025-11-06 11:30:17.713	2025-11-06 12:30:08.442
cmhnckmrh001njuhz994hvaxo	pdubey809@gmail.com	Bhupendra Dubey	EMPLOYEE	$2b$10$AYFHSBhEOLljNmbyuNcNfebqQmwt1P4oGHCZyimVdmWNIVGu65ADm	\N	\N	\N	\N	\N	2025-11-06 11:32:29.885	2025-11-06 11:32:29.885
cmhncmc68001qjuhz1jeka6p6	gajanan.amin@gmail.com	Gajanan Amin	EMPLOYEE	$2b$10$XwMbpVd3fDq0jzOCL/DB.OmAPhO4az69kujyvNuQVHq6C3UORKotS	\N	\N	\N	\N	\N	2025-11-06 11:33:49.473	2025-11-06 11:33:49.473
cmhncn6gd001rjuhzwh4dxlic	ajayjoshuva1994.a@gmail.com	ajayjoshuva1994.a@gmail.com	EMPLOYEE	$2b$10$4E7IoRrRqhwIgYFSQBSFbuX17cM2r4aPk8ZMMZd7A4hXbR8ypSOim	2025-11-06 14:09:35.033	\N	\N	\N	2025-11-06 14:09:48.148	2025-11-06 11:34:28.717	2025-11-06 14:09:48.149
cmhloo3jh000xjuhzly3m6w5s	mdfairoz77@gmail.com	Mohammed Fairoz	EMPLOYEE	$2b$10$oy8zn8hziVQlHJfE9Cna9uYFEqTxBycKRbavry6pnGp7dPXfDKqeK	2025-11-05 07:36:32.299	\N	\N	\N	2025-11-10 11:29:50.166	2025-11-05 07:35:34.637	2025-11-10 11:29:50.167
1	technicalco-ordinator@ayurcentral.in	Technical Co-ordinator	ADMIN	$2b$10$Xw1kDx5UGcEzgXdYxQ6CEe2RpPUgdUC5TBZeguRdMQOAQTd75BcDK	2025-10-16 08:39:14.573	\N	\N	\N	2025-11-12 09:01:36.791	2025-10-13 10:00:50.479	2025-11-12 09:01:36.794
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: itsupport
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c0c8b0a1-f78e-4690-a77a-80022eacc389	cd746bceb7c8c8317d8e265293724f5bd4b6e70213e5618f59a425d9afb09166	2025-10-13 07:19:09.981528+00	20250902101912_init	\N	\N	2025-10-13 07:19:09.91986+00	1
e42ba909-e058-4ce7-9cdf-d7f3c42e3c8f	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	2025-10-13 07:19:09.984881+00	20250914105717_main-module-enhancements	\N	\N	2025-10-13 07:19:09.982641+00	1
96ceb2f5-72b5-4878-a589-2b48ca54316f	105ef74a9a40dc4449b84cefbf172a1df9881b22be493dbba311a36ce58d19f0	2025-10-13 07:19:10.025339+00	20250914105732_main-module-enhancements	\N	\N	2025-10-13 07:19:09.985959+00	1
\.


--
-- Name: EmployeeMainModuleProgress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itsupport
--

SELECT pg_catalog.setval('public."EmployeeMainModuleProgress_id_seq"', 1, false);


--
-- Name: MainModule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itsupport
--

SELECT pg_catalog.setval('public."MainModule_id_seq"', 22, true);


--
-- Name: QuestionImport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itsupport
--

SELECT pg_catalog.setval('public."QuestionImport_id_seq"', 1, false);


--
-- Name: Attempt Attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Attempt"
    ADD CONSTRAINT "Attempt_pkey" PRIMARY KEY (id);


--
-- Name: Certificate Certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeMainModuleProgress EmployeeMainModuleProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."EmployeeMainModuleProgress"
    ADD CONSTRAINT "EmployeeMainModuleProgress_pkey" PRIMARY KEY (id);


--
-- Name: MainModule MainModule_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."MainModule"
    ADD CONSTRAINT "MainModule_pkey" PRIMARY KEY (id);


--
-- Name: Module Module_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Module"
    ADD CONSTRAINT "Module_pkey" PRIMARY KEY (id);


--
-- Name: QuestionImport QuestionImport_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."QuestionImport"
    ADD CONSTRAINT "QuestionImport_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: Quiz Quiz_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Quiz"
    ADD CONSTRAINT "Quiz_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Attempt_userId_quizId_attemptNo_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "Attempt_userId_quizId_attemptNo_key" ON public."Attempt" USING btree ("userId", "quizId", "attemptNo");


--
-- Name: Certificate_mainModuleId_idx; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE INDEX "Certificate_mainModuleId_idx" ON public."Certificate" USING btree ("mainModuleId");


--
-- Name: Certificate_userId_idx; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE INDEX "Certificate_userId_idx" ON public."Certificate" USING btree ("userId");


--
-- Name: Certificate_userId_mainModuleId_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "Certificate_userId_mainModuleId_key" ON public."Certificate" USING btree ("userId", "mainModuleId");


--
-- Name: EmployeeMainModuleProgress_employeeId_mainModuleId_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "EmployeeMainModuleProgress_employeeId_mainModuleId_key" ON public."EmployeeMainModuleProgress" USING btree ("employeeId", "mainModuleId");


--
-- Name: Module_order_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "Module_order_key" ON public."Module" USING btree ("order");


--
-- Name: Quiz_moduleId_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "Quiz_moduleId_key" ON public."Quiz" USING btree ("moduleId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: itsupport
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Attempt Attempt_quizId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Attempt"
    ADD CONSTRAINT "Attempt_quizId_fkey" FOREIGN KEY ("quizId") REFERENCES public."Quiz"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Attempt Attempt_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Attempt"
    ADD CONSTRAINT "Attempt_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Certificate Certificate_mainModuleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_mainModuleId_fkey" FOREIGN KEY ("mainModuleId") REFERENCES public."MainModule"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Certificate Certificate_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmployeeMainModuleProgress EmployeeMainModuleProgress_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."EmployeeMainModuleProgress"
    ADD CONSTRAINT "EmployeeMainModuleProgress_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeMainModuleProgress EmployeeMainModuleProgress_mainModuleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."EmployeeMainModuleProgress"
    ADD CONSTRAINT "EmployeeMainModuleProgress_mainModuleId_fkey" FOREIGN KEY ("mainModuleId") REFERENCES public."MainModule"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Module Module_mainModuleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Module"
    ADD CONSTRAINT "Module_mainModuleId_fkey" FOREIGN KEY ("mainModuleId") REFERENCES public."MainModule"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QuestionImport QuestionImport_uploadedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."QuestionImport"
    ADD CONSTRAINT "QuestionImport_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Question Question_quizId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_quizId_fkey" FOREIGN KEY ("quizId") REFERENCES public."Quiz"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Quiz Quiz_moduleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: itsupport
--

ALTER TABLE ONLY public."Quiz"
    ADD CONSTRAINT "Quiz_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES public."Module"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict UWJdsNTpGSzgPMQTFC4NJfKhKp7CGq0aiLQh69X7oftRqH2aDpbBjAivMKfsRAL

